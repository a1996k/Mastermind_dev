﻿var theDataTable;
var gstDataTable;
var speedList;
var serviceSortable, helperSortable;
var serviceAdditionHelperTarget;

function AdminNav() {
    var toLoad = $(this).attr('data-ajax-load');
    $('.hidden-navver').val(toLoad);

    $.ajax({
        type: 'GET',
        url: ProcessUrl('AdminNav/' + toLoad),
        beforeSend: function () {
            $('.viewer-container').addClass('d-none');
            $('.admin-nav-group button').prop('disabled', true);
            //$('.dynamic-button-home').html('');
            $('#psDataTable thead').html('');
            $('.viewer').html('');
            $('.sidebar-container').parent().hide();
            $('.sidebar-container').html('');
            if (theDataTable) {
                //destroy the dataTable
                $(theDataTable).DataTable().destroy();
            }
        },
        success: function (data) {
            var res = JSON.parse(data);
            if (typeof res.sideBar !== 'undefined') {
                $('.sidebar-container').html(res.sideBar);
                //$('.dynamic-button-home').html(res.createButtonHtml);
                $('#psDataTable thead').html(res.tableHeader);
                $('.viewer-container').removeClass('d-none');
                $('.sidebar-container').parent().show();
                $('.fc-table-content button').hide();
                $('.fc-table-content button[data-ajax-load="' + toLoad + '"]').show();
            } else {
                $('#psDataTable thead').html(res.tableHeader);
                $('#psDataTable .viewer').html(res.theView);
                theDataTable = $('#psDataTable').DataTable();
                //$('.dynamic-button-home').html(res.createButtonHtml);
                $('.viewer-container').removeClass('d-none');
                $('.fc-table-content button').hide();
                $('.fc-table-content button[data-ajax-load="' + toLoad + '"]').show();
            }
        },
        complete: function () {
            $('.admin-nav-group button').prop('disabled', false);
        }
    });
};

function AjaxNewService() {
    if (typeof serviceSortable !== 'undefined') {
        serviceSortable.sortable('destroy');
    }
    $.get(ProcessUrl('service/new'), function (data) {
        $('#edit_service_modal .modal-body').html(JSON.parse(data));
        ppSortable = $('.default-prepress-services').sortable();
        fSortable = $('.default-finishing-services').sortable();
        $('#editservicemodal').trigger('click');
    });
};
function AjaxNewMaterial() {
    $.get(ProcessUrl('material/new'), function (data) {
        $('#new_material_modal .modal-body').html(JSON.parse(data));
        $('#newmaterialmodal').trigger('click');
    });
};
function AjaxNewPress() {
    if (typeof fSortable !== 'undefined') {
        fSortable.sortable('destroy');
    }
    if (typeof ppSortable !== 'undefined') {
        ppSortable.sortable('destroy');
    }
    $.get(ProcessUrl('press/new'), function (data) {
        $('#new_press_modal .modal-body').html(JSON.parse(data));
        ppSortable = $('.default-prepress-services').sortable();
        fSortable = $('.default-finishing-services').sortable();
        $('#newpressmodal').trigger('click');
        $('#newpressmodal').trigger('click');
    });
};
function AjaxNewServiceCategory() {
    $.get(ProcessUrl('servicecat/new'), function (data) {
        $('#new_service_cat_modal .modal-body').html(JSON.parse(data));
        $('#newservicecatmodal').trigger('click');
    });
};
function AjaxNewUser() {
    $.get(ProcessUrl('user/new'), function (data) {
        $('#new_user_modal .modal-body').html(JSON.parse(data));
        $('#newusermodal').trigger('click');
    });
};
function AjaxNewClient() {
    $.get(ProcessUrl('client/new'), function (data) {
        $('#new_client_modal .modal-body').html(JSON.parse(data));
        $('#newclientmodal').trigger('click');
    });
};
function AjaxEditClient() {
    var clientId = $(this).attr('data-record-id');

    $.get(ProcessUrl('client/edit/' + clientId), function (data) {
        $('#edit_client_modal .modal-body').html(JSON.parse(data));
        $('#editclientmodal').trigger('click');
    });
};
function AjaxEditPlate() {
    var plateId = $(this).attr('data-record-id');

    $.get(ProcessUrl('plate/edit/' + plateId), function (data) {
        $('#edit_plate_modal .modal-body').html(JSON.parse(data));
        $('#editplatemodal').trigger('click');
    });
};
function AjaxNewPlate() {
    $.get(ProcessUrl('plate/new'), function (data) {
        $('#edit_plate_modal .modal-body').html(JSON.parse(data));
        $('#editplatemodal').trigger('click');
    });
};

function AjaxEditServiceCategory() {
    var $row = $(this);
    var r_id = $row.attr('data-record-id');
    var itemTitle = $row.attr('data-item-title');

    $('#edit_service_cat_modal h5.modal-title span').html(itemTitle);

    $.get(ProcessUrl('servicecat/edit/' + r_id), function (data) {
        $('#edit_service_cat_modal .modal-body').html(JSON.parse(data));
        $('#editservicecatmodal').trigger('click');
    });
};
function AjaxEditService() {
    var $row = $(this);
    var r_id = $row.attr('data-record-id');
    var itemTitle = $row.attr('data-item-title');

    $('#edit_service_modal h5.modal-title span').html(itemTitle);

    if (typeof fSortable !== 'undefined') {
        fSortable.sortable('destroy');
    }
    if (typeof ppSortable !== 'undefined') {
        ppSortable.sortable('destroy');
    }

    $.get(ProcessUrl('service/edit/' + r_id), function (data) {
        $('#edit_service_modal .modal-body').html(JSON.parse(data));
        ppSortable = $('.default-prepress-services').sortable();
        fSortable = $('.default-finishing-services').sortable();
        $('#editservicemodal').trigger('click');
    });
};

function AjaxEditMaterial() {
    var $row = $(this);
    var r_id = $row.attr('data-record-id');
    var itemTitle = $row.attr('data-item-title');

    $('#edit_material_modal h5.modal-title span').html(itemTitle);

    $.get(ProcessUrl('material/edit/' + r_id), function (data) {
        $('#edit_material_modal .modal-body').html(JSON.parse(data));
        $('#editmaterialmodal').trigger('click');
    });
};

function AjaxEditUser() {
    var $row = $(this);
    var r_id = $row.attr('data-record-id');
    var itemTitle = $row.attr('data-item-title');

    $('#edit_user_modal h5.modal-title span').html(itemTitle);

    $.get(ProcessUrl('user/edit/' + r_id), function (data) {
        $('#edit_user_modal .modal-body').html(JSON.parse(data));
        $('#editusermodal').trigger('click');
    });
};

function AjaxEditPress() {
    var $row = $(this);
    var r_id = $row.attr('data-record-id');
    var itemTitle = $row.attr('data-item-title');

    $('#edit_press_modal h5.modal-title span').html(itemTitle);

    if (typeof serviceSortable !== 'undefined') {
        serviceSortable.sortable('destroy');
    }

    $.get(ProcessUrl('press/edit/' + r_id), function (data) {
        $('#edit_press_modal .modal-body').html(JSON.parse(data));
        serviceSortable = $('.default-services').sortable();
        helperSortable = $('.helper-services').sortable();
        $('#editpressmodal').trigger('click');
    });
};

function GetPressHelperServices() {
    let arr = new Array();
    let pressId = $('#Press_Id').val();

    $('.helper-services li.service-entry').each(function () {
        let $ele = $(this);

        let s = {
            Id: $ele.attr('data-record-id'),
            Press: pressId,
            Service: $ele.attr('data-service-id')
        };

        arr.push(s);
    });

    return arr;
};
function GetDefaultPressServices() {
    let ctr = 1;
    let arr = new Array();
    let pressId = $('#Press_Id').val();
    let stockTypeId = $('.stock-type-group .active-choice').attr('data-record-id');
    $('.default-services li.service-entry').each(function () {
        let $ele = $(this);

        let s = {
            'Id': $ele.attr('data-record-id'),
            'Service': $ele.attr('data-service-id'),
            'Press': pressId,
            'Ordinal': ctr,
            'StockType': stockTypeId
        };

        arr.push(s);

        ctr++;
    });

    return arr;
};

function GetServiceFinishingServices() {
    if ($('.default-finishing-services li.service-entry').length > 0) {
        var arr = new Array();
        var serviceId = $('#Service_Id').val();

        let oTracker = 1;

        $('.default-finishing-services li.service-entry').each(function () {
            var s = {
                'Id': $(this).attr('data-record-id'),
                'LinkedService': $(this).attr('data-service-id'),
                'PrimaryService': serviceId,
                'Ordinal': oTracker
            };

            arr.push(s);

            oTracker++;
        });

        return arr;
    }
};

function GetServicePrepressServices() {
    if ($('.default-prepress-services li.service-entry').length > 0) {
        var arr = new Array();
        var serviceId = $('#Service_Id').val();

        let oTracker = 1;

        $('.default-prepress-services li.service-entry').each(function () {
            var s = {
                'Id': $(this).attr('data-record-id'),
                'LinkedService': $(this).attr('data-service-id'),
                'PrimaryService': serviceId,
                'Ordinal': oTracker
            };

            arr.push(s);

            oTracker++;
        });

        return arr;
    }
};

//TRYING OUT
function serializedToJson(serialized) {
    var json = {};
    var pairs = serialized.split('&');

    pairs.forEach(function (pair) {
        var parts = pair.split('=');
        var key = decodeURIComponent(parts[0]);
        var value = decodeURIComponent(parts[1]);

        // Remove the entity from the beginning of the key
        key = key.replace(/^Press\./, '');
        key = key.replace(/^Constraint\./, '');
        key = key.replace(/^Service\./, '');
        key = key.replace(/^User\./, '');
        key = key.replace(/^ServiceCategory\./, '');
        key = key.replace(/^Material\./, '');
        key = key.replace(/^PressSpeed\./, '');
        key = key.replace(/^Client\./, '');

        if (json[key] !== undefined) {
            if (!Array.isArray(json[key])) {
                json[key] = [json[key]];
            }
            json[key].push(value);
        } else {
            json[key] = value;
        }
    });

    return json;
};

function GetClientShippingAddresses() {
    let arr = [];
    $('.ship-address-list li').each(function () {
        let $item = $(this);
        let $address = {};

        $address.Id = $item.attr('data-record-id');
        $address.Client = $('#Client_Id').val();
        $address.Address = $item.find('#Address').val();
        $address.Address2 = $item.find('#Address2').val();
        $address.Attention = $item.find('#Attention').val();
        $address.City = $item.find('#City').val();
        $address.State = $item.find('#State').val();
        $address.Phone = $item.find('#Phone').val();
        $address.Zip = $item.find('#Zip').val();
        $address.Notes = $item.find('#Notes').val();
        $address.IsDefaultForClient = $item.find('input[name="saRadio"]').is(':checked');
        $address.CustomerName = $item.find('#CustomerName').val();
        arr.push($address);
    });

    return arr;
};

function GetClientContacts() {
    let arr = [];

    $('.contact-list li').each(function () {
        let $item = $(this);
        let $contact = {};

        $contact.Id = $item.attr('data-record-id');
        $contact.CusNo = $('#Client_Id').val();
        $contact.First = $item.find('#First').val();
        $contact.Last = $item.find('#Last').val();
        $contact.Phone = $item.find('#Phone').val();
        $contact.Fax = $item.find('#Fax').val();
        $contact.Email = $item.find('#Email').val();
        $contact.Position = $item.find('#Position').val();
        $contact.Options = $item.find('#Options').val();
        $contact.Phone2 = $item.find('#Phone2').val();
        $contact.Cell = $item.find('#Cell').val();
        $contact.KeyContact = $item.find('#KeyContact').val();
        $contact.ContactNote = $item.find('#ContactNote').val();
        $contact.ShipTo = $item.find('#ShipTo').val();
        $contact.ConTag = $item.find('#ConTag').val();

        arr.push($contact);
    });

    return arr;
};

function FormSubmitOverride(e) {
    e.preventDefault();
    var endpoint = $(e.target).attr('action');
    var props = $(this).serialize();

    //get the item type off of the form
    var itemType = $(e.target).attr('data-item-type');
    var itemTypeLower = itemType.toLowerCase();
    var theJson = serializedToJson(props);

    var dpsReturn = GetDefaultPressServices();
    var phsReturn = GetPressHelperServices();
    var sppsReturn = GetServicePrepressServices();
    var sfsReturn = GetServiceFinishingServices();

    if (itemTypeLower === 'press') {
        var savePress = {};
        savePress.theItem = theJson;
        savePress.DefaultPressServices = dpsReturn;
        savePress.HelperServices = phsReturn;
        savePress.StockType = $('.stock-type-group .active-choice').attr('data-record-id');

        console.log(savePress);

        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                savePress: savePress
            }
        });
    }
    else if (itemTypeLower === 'service') {
        theJson.Required = $('#Service_Required').prop('checked');
        theJson.IsTimed = $('#Service_IsTimed').prop('checked');
        theJson.IsCuttingService = $('#Service_IsCuttingService').prop('checked');
        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                theItem: theJson,
                FinishingServices: sfsReturn,
                PrepressServices: sppsReturn
            }
        });
    }
    else if (itemTypeLower === 'constraint') {
        //hacky but idc; note that this clears an existing maximum if changed and saved.
        if (theJson.ConstraintType !== '1') {
            theJson.MaxValue = $('#Constraint_MinValue').val();
        }

        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                constraint: theJson,
                press: $('#Press_Id').val()
            },
            complete: GetPressConstraints
        });
    }
    else if (itemTypeLower === 'pressspeed') {
        theJson.Press = $('#Press_Id').val();
        theJson.IsDefault = $('#IsDefault_Value').val();

        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                pressSpeed: theJson
            },
            complete: GetPressSpeeds
        });
    }
    else if (itemTypeLower === 'customer') {
        theJson.ShippingAddresses = GetClientShippingAddresses();
        theJson.Contacts = GetClientContacts();
        theJson.BlindShipping = $('#Client_BlindShipping_Value').is(':checked');

        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                theItem: theJson
            }
        });
    }
    else if (itemTypeLower === 'user') {
        theJson.IsSpecialApprover = $('#User_IsSpecialApprover_Value').is(':checked');
    }
    else {
        $.ajax({
            type: 'POST',
            url: ProcessUrl(endpoint),
            data: {
                theItem: theJson
            }
        });
    }
};

function AddDefaultServices() {
    serviceAdditionHelperTarget = '.default-services';
};

function AddHelperServices() {
    serviceAdditionHelperTarget = '.helper-services';
};

function AddDefaultServicesToPress() {
    //get the following attributes from all #general_service_table tr recoreds that have a checked child
    // data-record-id and data-record-title
    var selectedServices = [];
    $('#general_service_table tr').each(function () {
        var $row = $(this);
        var $checkbox = $row.find('input[type="checkbox"]');
        if ($checkbox.is(':checked')) {
            selectedServices.push({
                id: $row.attr('data-record-id'),
                title: $row.attr('data-record-title')
            });
        }
    });

    var listSelector;

    listSelector = serviceAdditionHelperTarget;

    for (var i = 0; i < selectedServices.length; i++) {
        $(listSelector).prepend(
            `<li class="service-entry d-flex flex-row justify-content-between" data-record-id="0" data-service-id="${selectedServices[i].id}">
            <span class="title">${selectedServices[i].title}</span>
            <span class="remove-link">
                <i class="fa-solid fa-minus" style="color: #8f0000;"></i>
            </span>
        </li>`);
    }
};

function AddDefaultServicesToService() {
    var selectedServices = [];
    $('#general_service_table tr').each(function () {
        var $row = $(this);
        var $checkbox = $row.find('input[type="checkbox"]');
        if ($checkbox.is(':checked')) {
            selectedServices.push({
                id: $row.attr('data-record-id'),
                title: $row.attr('data-record-title')
            });
        }
    });

    var serviceType = $('#general_service_table tbody tr:first-child').attr('data-type-of-service');

    var listSelector;

    switch (serviceType) {
        case 'prepress':
            listSelector = '.default-prepress-services';
            break;
        case 'finishing':
            listSelector = '.default-finishing-services';
            break;
        default:
            listSelector = '';
    }

    for (var i = 0; i < selectedServices.length; i++) {
        $(listSelector).prepend(
            `<li class="service-entry d-flex flex-row justify-content-between" data-record-id="0" data-service-id="${selectedServices[i].id}">
            <span class="title">${selectedServices[i].title}</span>
            <span class="remove-link">
                <i class="fa-solid fa-minus" style="color: #8f0000;"></i>
            </span>
        </li>`);
    }
};

function GetConstraint() {
    let cId = $(this).parent().parent().attr('data-record-id');

    $('#constraint_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('constraint/get/' + cId + '/1'), function (data) {
            $('#constraint_list .modal-body').html(JSON.parse(data));
            $('#constraint_list .modal-footer').fadeOut('slow', function () {
                $('#constraint_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function CheckConstraintType() {
    $.get(ProcessUrl('ConstraintTypeCheck/' + $('#Constraint_ConstraintType').val()), function (data) {
        switch (data) {
            case 'value':
                $('.change-for-value').text('Value');
                $('.hide-for-value').hide();
                break;
            case 'range':
                $('.change-for-value').text('MinValue');
                $('.hide-for-value').show();
                break;
            default:
                //do nothing
                break;
        }
    });
};

function NewConstraint() {
    $('#constraint_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('constraint/new'), function (data) {
            $('#constraint_list .modal-body').html(JSON.parse(data));
            $('#constraint_list .modal-footer').fadeOut('slow', function () {
                $('#constraint_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function CancelConstraint() {
    $('#constraint_list').modal('hide');
    $('#vc').trigger('click');
};

function GetPressConstraints() {
    var pressId = $('#Press_Id').val();

    $('#constraint_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('constraints/' + pressId), function (data) {
            $('#constraint_list .modal-body').html(JSON.parse(data));
            $('#constraint_list .modal-footer').fadeIn('fast', function () {
                $('#constraint_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function SetClassOnButton(evt) {
    //check .hidden-navver and update the button as appropriate
    let hv = $('.hidden-navver').val();

    switch (hv) {
        case 'Services':
            $('.general-service-add').removeClass('general-service-add-presses').addClass('general-service-add-services');
            break;
        case 'Presses':
            $('.general-service-add').removeClass('general-service-add-services').addClass('general-service-add-presses');
            break;
        default:
            break;
    }
};

function GetPressSpeeds() {
    var pressId = $('#Press_Id').val();

    $('#speed_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('get-press-speeds/' + pressId), function (data) {
            $('#speed_list .modal-body').html(data);
            $('#speed_list .modal-footer').fadeIn('fast', function () {
                $('#speed_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function GetPressSpeed() {
    let cId = $(this).parent().parent().attr('data-record-id');

    $('#speed_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('get-press-speed/' + cId), function (data) {
            $('#speed_list .modal-body').html(data);
            $('#speed_list .modal-footer').fadeOut('slow', function () {
                $('#speed_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function NewPressSpeed() {
    $('#speed_list .modal-body').fadeOut('slow', function () {
        $.get(ProcessUrl('get-press-speed'), function (data) {
            $('#speed_list .modal-body').html(data);
            $('#speed_list .modal-footer').fadeOut('slow', function () {
                $('#speed_list .modal-body').fadeIn('fast');
            });
        });
    });
};

function SaveSpeedArrangement() {
    //build an array of speed id/ordinal values

    var items = $('.p-speeds li:not(:first-child)');
    var itemCt = items.length;
    var idArr = new Array();
    var ordinalArr = new Array();

    for (var i = 1; i <= itemCt; i++) {
        let item = items[(i - 1)];

        idArr.push($(item).attr('data-record-id'));
        ordinalArr.push(i);
    }

    var obj = {};
    obj.SpeedIds = idArr;
    obj.SpeedOrdinals = ordinalArr;

    $.ajax({
        type: 'POST',
        url: ProcessUrl('save-speed-arrangement'),
        data: {
            arrangement: obj
        },
        beforeSend: function () {
            $('body').addClass('pe-none');
        },
        complete: function () {
            $('body').removeClass('pe-none');
        }
    });
};

function ShowHideMinRunTime() {
    $('.min-run-time-block').is(':visible') ?
        $('.min-run-time-block').hide() :
        $('.min-run-time-block').show();
};

function LoadCategory() {
    var $cat = $(this);

    var catId = $cat.attr('data-record-id');
    var recordType = $cat.attr('data-record-type');
    //load cat items

    $.ajax({
        type: 'POST',
        url: ProcessUrl('admin/load-cat'),
        data: {
            id: catId,
            type: recordType
        },
        beforeSend: function () {
            $('.viewer-container').addClass('d-none');
            $('.viewer').html('');
            if (theDataTable) {
                console.log('Destroying datatable');
                $(theDataTable).DataTable().destroy();
            }
        },
        success: function (data) {
            try {
                var res = JSON.parse(data);
                $('.viewer').html(res.theView);
                theDataTable = $('#psDataTable').DataTable({
                    pageLength: 100
                });
                $('.viewer-container').removeClass('d-none');

                $('.sidebar-wrapper').on('click', LoadCategory);
            } catch (e) { }
        }
    });
};

function ToggleStockType() {
    var $btn = $(this);
    var stockTypeId = $btn.attr('data-record-id');
    var pressId = $btn.parent().attr('data-press-id');

    $.ajax({
        type: 'GET',
        url: ProcessUrl('load-stock-config/' + stockTypeId + '/' + pressId),
        success: function (data) {
            var res = JSON.parse(data);

            if (res.HasRecord) {
                $('.edit-zone').html(res.Html);
                //re-enable sortables
                //ppSortable = $('.default-prepress-services').sortable();
                //fSortable = $('.default-finishing-services').sortable();
                serviceSortable = $('.default-services').sortable();
            } else {
                $('#new_stock_type_modal').modal('show');
            }
        },
        complete: function () {
            $('.stock-type-group button.active-choice').removeClass('active-choice');
            $btn.addClass('active-choice');
        }
    });
};

function CancelStockType() {
    $('#new_stock_type_modal').modal('hide');
    $('button.sheet').trigger('click');
};

function NewStockType() {
    //ajax request the stock id and original press to the backend
    var origPress = $('#Press_Id').val();
    var stockId = $('.stock-type-group button.active-choice').attr('data-record-id');

    $.ajax({
        type: 'POST',
        url: ProcessUrl('new-stock-for-press'),
        data: {
            sourcePress: origPress,
            stockId: stockId
        },
        success: function (data) {
            console.log(data);
        },
        error: function (err) {
            console.log(err);
        },
        complete: function () {
            $('.stock-type-group button[data-record-id="' + stockId + '"]').trigger('click');
        }
    });
};

function RemoveContactFromClient() {
    let $row = $(this).parent();
    let rId = $row.attr('data-record-id');

    //ajax request the id to the backend and remove the contact record
    //remove the $row from the html
    $.ajax({
        type: 'POST',
        url: ProcessUrl('remove-contact-from-client'),
        data: {
            id: rId
        },
        complete: function () {
            $row.remove();
        }
    });
};

function AddContactToClient() {
    let clientId = $('#Client_Id').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('new-contact-for-client'),
        data: {
            clientId: clientId
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('.contact-list').append(res);
            } catch (e) { }
        }
    });
};

function AddAddressToClient() {
    let clientId = $('#Client_Id').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('new-address-for-client'),
        data: {
            clientId: clientId
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('.ship-address-list').append(res);
            } catch (e) { }
        }
    });
};

function SaveTimeAdjustment() {
    let $btn = $(this);
    let $li = $btn.parents('li');
    let userId = $li.attr('data-user-id');
    let caId = $li.attr('data-ca-id');
    let ebId = $li.attr('data-eb-id');

    let saveObject = {
        UserId: userId,
        ClockActivityId: caId,
        BreakRecordId: ebId,
        ClockInTime: $li.find('.time-in').val(),
        ClockOutTime: $li.find('.time-out').val(),
        BreakStartTime: $li.find('.break-start').val(),
        BreakEndTime: $li.find('.break-end').val()
    };

    $.ajax({
        type: 'POST',
        url: ProcessUrl('save-clock-activity'),
        beforeSend: function () {
            $btn.prop('disabled', true);
        },
        data: {
            clockUpdate: saveObject
        },
        complete: function (data) {
            $btn.prop('disabled', false);
        }
    });
};

function LoadUserClockActivity() {
    let $btn = $(this);
    let userId = $btn.attr('data-record-id');

    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-clock-activity') + '/' + userId,
        beforeSend: function () {
            $('#clock_activity_edit_modal .modal-body ul').html('');
        },
        success: function (data) {
            //load data here
            try {
                let res = JSON.parse(data);

                for (let i = 0; i < res.length; i++) {
                    let thisRow =
                        `<li data-user-id="${res[i].UserId}" data-ca-id="${res[i].ClockActivityId}" data-eb-id="${res[i].EmployeeBreakId}">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="field-binder-row-flex">
                                        <div class="field-binder-col-flex fs-3">
                                            <span>${res[i].EventDateString}</span>
                                        </div>
                                        <div class="field-binder-col-flex ps-4">
                                            <label class="fs-4">Start Time</label>
                                            <input type="time" class="time-in" value="${res[i].TimeInString}" />
                                        </div>
                                        <div class="field-binder-col-flex ps-4">
                                            <label class="fs-4">Lunch Start</label>
                                            <input type="time" class="break-start" value="${res[i].BreakStartString}" />
                                        </div>
                                        <div class="field-binder-col-flex ps-4">
                                            <label class="fs-4">Lunch End</label>
                                            <input type="time" class="break-end" value="${res[i].BreakEndString}" />
                                        </div>
                                        <div class="field-binder-col-flex ps-4">
                                            <label class="fs-4">End Time</label>
                                            <input type="time" class="time-out" value="${res[i].TimeOutString}" />
                                        </div>
                                        <button type="button" class="btn btn-sm btn-fc-info save-this-row ms-3">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>`;

                    $('#clock_activity_edit_modal .modal-body ul').append(thisRow);
                }
            } catch (e) { }
        }
    });
};

function DeleteShippingAddress() {
    var $btn = $(this);
    var $li = $btn.parents('li');
    var recordId = $btn.attr('data-record-id');

    $.ajax({
        type: 'POST',
        url: ProcessUrl('delete-shipping-address'),
        data: {
            recordId
        },
        success: function () {
            $li.remove();
        }
    });
};

function SetPassword() {
    let newPassword = $('.new-password-inp').val();
    let newPasswordConf = $('.new-password-conf-inp').val();

    if (newPassword === newPasswordConf) {
        $.ajax({
            type: 'POST',
            url: ProcessUrl('set-password'),
            data: {
                newPassword
            },
            success: function () {
                alert('Password updated');
            },
            error: function (err) {
                console.log(err);
                alert('Error changing password');
            }
        });
    } else {
        alert('Passwords do not match');
    }
};

$(function () { })
    .on('click', '.admin-nav-group button', AdminNav)
    .on('click', '.admin-edit-item-material', AjaxEditMaterial)
    .on('click', '.admin-edit-item-service', AjaxEditService)
    .on('click', '.admin-edit-item-press', AjaxEditPress)
    .on('click', '.admin-edit-item-servicecategory', AjaxEditServiceCategory)
    .on('click', '.admin-edit-item-user', AjaxEditUser)
    .on('click', '.admin-edit-item-plate', AjaxEditPlate)
    .on('click', '.admin-edit-item-customer', AjaxEditClient)
    .on('click', '.new-press-btn', AjaxNewPress)
    .on('click', '.new-material-btn', AjaxNewMaterial)
    .on('click', '.new-service-btn', AjaxNewService)
    .on('click', '.new-service-cat-btn', AjaxNewServiceCategory)
    .on('click', '.new-user-btn', AjaxNewUser)
    .on('click', '.new-plate-btn', AjaxNewPlate)
    .on('click', '.new-customer-btn', AjaxNewClient)
    .on('submit', 'form:not(#param_form)', FormSubmitOverride)
    .on('click', '.add-default-service', AddDefaultServices)
    .on('click', '.add-helper-service', AddHelperServices)
    .on('click', '.general-service-add-presses', AddDefaultServicesToPress)
    .on('click', '.general-service-add-services', AddDefaultServicesToService)
    .on('click', '.edit-constraint-link', GetConstraint)
    .on('click', '.new-constraint', NewConstraint)
    .on('click', '.cancel-constraint', CancelConstraint)
    .on('click', '.vc-wrapper', GetPressConstraints)
    .on('click', '.ps-wrapper', GetPressSpeeds)
    .on('click', '.edit-speed-link', GetPressSpeed)
    .on('change', '#Constraint_ConstraintType', CheckConstraintType)
    .on('show.bs.modal', '#general_service_modal', SetClassOnButton)
    .on('click', '.new-speed', NewPressSpeed)
    .on('sortstop', '.p-speeds', SaveSpeedArrangement)
    .on('change', '#Service_CatNo', ShowHideMinRunTime)
    .on('click', '.sidebar-wrapper li', LoadCategory)
    .on('click', '.stock-type-group button', ToggleStockType)
    .on('click', '.new-stock-type-btn', NewStockType)
    .on('click', '.cancel-new-stock-type', CancelStockType)
    .on('click', '.add-contact-btn', AddContactToClient)
    .on('click', '.remove-contact-btn', RemoveContactFromClient)
    .on('click', '.new-address-btn', AddAddressToClient)
    .on('click', '.edit-clock-activity', LoadUserClockActivity)
    .on('click', '.save-this-row', SaveTimeAdjustment)
    .on('click', '.delete-sa-btn', DeleteShippingAddress)
    .on('click', '.submit-password', SetPassword);
﻿class Timer {
    constructor(activeTimerId) {
        this.seconds = 0;
        this.intervalId = null;
        this.updateCallback = null;
        this.timerDisplay = document.getElementById(activeTimerId);
    }

    start(updateCallback) {
        this.updateCallback = updateCallback;
        this.intervalId = setInterval(() => {
            this.seconds++;
            this.updateDisplay();
        }, 1000);
    }

    stop() {
        clearInterval(this.intervalId);
    }

    reset() {
        this.seconds = 0;
        this.updateDisplay();
    }

    updateDisplay() {
        const hours = Math.floor(this.seconds / 3600);
        const minutes = Math.floor((this.seconds % 3600) / 60);
        const seconds = this.seconds % 60;

        const formattedTime = `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

        if (this.updateCallback) {
            this.updateCallback(formattedTime);
        }
    }
}

//currently only getting by user
function GetJobs() {
    let searchOption = $('input[name="searchOption"]:checked').attr('data-search-option');
    let url = 'time-entries-by-' + searchOption;
    let userId = $('#Users').val();

    $.ajax({
        type: 'GET',
        url: ProcessUrl(url),
        data: {
            userId: userId
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);

                $('.record-dest').html('');
                for (var i = 0; i < res.length; i++) {
                    $('.record-dest').append(
                        `<li>

                        </li>`
                    )
                }
            } catch (e) { }
        }
    });
};
function AssignedOperatorQuickUpdate() {
    var $dd = $(this);
    var op = $dd.val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('add-operator-to-job'),
        data: {
            'op': op,
            'recordId': $dd.attr('data-record-id')
        }
    });
};

function ToggleSearchBy() {
    let $btn = $(this);
    let sType = $btn.attr('data-search-option');

    $('.search-option').hide();
    $('.search-option[data-search-option="' + sType + '"]').show();
};

$(function () {
})
    .on('click', '.submit-btn', GetJobs)
    .on('change', '.jis-dd', AssignedOperatorQuickUpdate)
    .on('click', 'input[name="searchOption"]', ToggleSearchBy);
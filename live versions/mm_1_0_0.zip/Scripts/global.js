﻿var currentMenuAction;
var comparerBase;

/* should be FifthPress when on dev, otherwise / */
//var urlPrefix = '/';

/* BUG/FEATURE REQUEST RELATED */
function ResetBugFormDefaults() {
    $('.bug-desc').val('');
    $('.bug-severity').val(1);
    $('.bug-priority').val(1);
    $('.bug-module').val(1);
    $('.bug-environment').val(1);
    $('.bug-str').val('');
    $('.bug-eb').val('');
    $('.bug-ab').val('');
};

function GetBug() {
    let bug = {};
    bug.Description = $('.bug-desc').val();
    bug.Severity = $('.bug-severity').val();
    bug.Priority = $('.bug-priority').val();
    bug.Module = $('.bug-module').val();
    bug.Environment = $('.bug-environment').val();
    bug.StepsToReproduce = $('.bug-str').val();
    bug.ExpectedBehavior = $('.bug-eb').val();
    bug.ActualBehavior = $('.bug-ab').val();

    return bug;
};
function SubmitBug() {
    let bug = GetBug();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('submit-bug'),
        data: {
            bug
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                alert('Bug Created with Id #' + res);

                ResetBugFormDefaults();
            } catch (e) { }
        }
    })
}

function ResetFeatureRequestFormDefaults() {
    $('.fr-desc').val('');
};

function GetFeatureRequest() {
    let fr = {};
    fr.Description = $('.fr-desc').val();

    return fr;
};
function SubmitFeatureRequest() {
    let featureRequest = GetFeatureRequest();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('submit-feature'),
        beforeSend: ResetFeatureRequestFormDefaults,
        data: {
            featureRequest
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                alert('Feature Request Created with Id #' + res);
            } catch (e) { }
        }
    })
};
/* END BUG/FEATURE RELATED */

function roundToDecimalPlace(num, decimalPlaces) {
    const factor = Math.pow(10, decimalPlaces);
    return Math.round(num * factor) / factor;
}

function UpdateMarkupPercentage(override) {
    $('.special-markup-btn').html(override);
};

function getSelectValueText(selectId) {
    if (selectId.indexOf("#") == -1) {
        selectId = "#" + selectId;
    }

    var select = document.getElementById(selectId);
    var selectedOption = select.options[select.selectedIndex];
    return selectedOption.text;
};
function SetActiveLink() {
    let curPage = window.location.pathname;

    $('a.nav-link').each(function () {
        if ($(this).attr('href') === curPage) {
            $(this).addClass('active');
        }
    });
};

function OpenModal() {
    var $m = $(this);
    if (typeof $m.attr('data-modal-to-open') !== 'undefined') {
        $($m.attr('data-modal-to-open')).modal('show');
    }
};
function CloseModal() {
    var $m = $(this);
    if (typeof $m.attr('data-modal-to-close') !== 'undefined') {
        if ($m.attr('data-modal-to-close') === '#') {
            //close the open modal
            $('.modal.show').modal('hide');
        } else {
            //close a specific modal
            $($m.attr('data-modal-to-close')).modal('hide');
        }
    }
};

function HasUnsavedChanges() {
    return $('[data-changed="True"]').length > 0;
};

/* assumes there are unsaved changes if called */
function UnsavedChangesHandler() {
    $('[data-changed="True"]').each(function () {
        var $e = $(this);

        if (alert('Unsaved Changes!')) {
            var recordId = $('input[name="Id"]').val();
            $.post('DeleteQuote/' + recordId);
        }
    });
};

function SetAsModified() {
    $(this).attr('data-changed', 'True');
};

function Submitted(evt) {
    return evt.type === 'submit';
};

function FormSubmitHandler(evt) {
    if (HasUnsavedChanges() && !Submitted(evt)) {
        evt.preventDefault();
        UnsavedChangesHandler(evt);
    }
};

function ClearChecks(context) {
    var ctx;
    if (typeof context !== 'undefined') {
        ctx = context + ' input[type="checkbox"]';
    } else {
        ctx = 'input[type="checkbox"]';
    }
    $(ctx).each(function () {
        $(this).prop('checked', false);
    });
};

function ProcessChecks(context) {
    var arr = new Array();
    var ctx;
    if (typeof context !== 'undefined') {
        ctx = context + ' input[type="checkbox"]:checked';
    } else {
        ctx = 'input[type="checkbox"]:checked';
    }

    $(ctx).each(function () {
        arr.push($(this).attr('data-record-id'));
    });

    return arr;
};

function RemoveFromTable() {
    //get the tr that contains the clicked button
    var $tr = $(this).closest('tr');
    //remove the tr from the table
    $tr.remove();
};

/* this function simply hides the item table (the button to add a row still shows, though) if there are
    no rows in the table, otherwise it shows. expected to be called by Add/Remove Row functions in quotes/estimates/jobs.js */
function TableRowRemoveAddHandler(table_id) {
    var tid = ('#' + table_id);
    var rowSelector = tid + ' tbody tr';

    if ($(rowSelector).length > 0) {
        $(tid).show();
    } else {
        $(tid).hide();
    }
};

function NonTableRowRemoveAddHandler() {
    var did = ('#job_items');
    var rowSelector = did + ' .item-row';

    if ($(rowSelector).length > 0) {
        $(did).show();

        if ($(rowSelector).length === 1) {
            var jobDesc = $('form textarea[id*="Description"]').val();
            $(rowSelector).find('.item-description').val(jobDesc);
            $(rowSelector).find('.service-list').sortable();
        }
    } else {
        $(did).hide();
    }

    var $pccf = $('#job_items .item-row:last-child').find('.press-color-count-front input');
    var $pccb = $('#job_items .item-row:last-child').find('.press-color-count-back input');

    if ($pccf.val() === '') {
        $pccf.val(4);
    }

    if ($pccb.val() === '') {
        $pccb.val(0);
    }
};

function ScrollPageToBottom(delay = 1500) {
    $('html, body').animate({ scrollTop: $(document).height() }, delay);
};

function JobDisplayGetDeliveryTicket() {
    var jId = $('.clicked-job').attr('data-record-id');
    window.location = ProcessUrl('delivery-ticket/' + jId);
};

function JobDisplayViewJob() {
    var jId = $('.clicked-job').attr('data-record-id');

    window.location = ProcessUrl('Job/View/' + jId);
};

function JobDisplayViewTicket() {
    var jId = $('.clicked-job').attr('data-record-id');

    window.location = ProcessUrl('GetJobTicket/' + jId);
};

function JobDisplayEditJob() {
    var jId = $('.clicked-job').attr('data-record-id');

    window.location = ProcessUrl('Job/Edit/' + jId);
};

function LedSelect() {
    var $clickedLed = $(this);
    var $cbPartner = $($clickedLed.attr('data-cb-partner'));
    var curVal = $cbPartner.is(':checked');
    curVal = !curVal;

    $cbPartner.prop('checked', curVal);

    if (curVal === true) {
        $clickedLed.addClass('selected');
    } else {
        $clickedLed.removeClass('selected');
    }
};

//removes the parent (and all children elements)
function RemoveParent() {
    $(this).parent().remove();
};

function RemoveParentListItem() {
    $(this).parents('li').remove();
};

function Login() {
    var oId = $('#operator_un').val();
    var oPwd = $('#operator_pcode').val();

    //console.log(oPwd);
    $.ajax({
        type: 'POST',
        url: ProcessUrl('login'),
        data: {
            userName: oId,
            passcode: oPwd
        },
        success: function (data) {
            var res = JSON.parse(data);
            //set welcome msg
            //show logged-in-wrapper
            //hide login button
            $('.u-welcome-msg').text(res.WelcomeMessage);
            $('.login-btn').hide();
            $('.logged-in-wrapper').show();
            $('#login #operator_un').val('');
            $('#login').modal('hide');
            window.location = ProcessUrl('PrintDashboard');
        },
        error: function (err) {
            console.log(err);
        }
    });
};

//gets the user id from the ActiveUser cookie and sends it to the backend. a new expired cookie is returned. easier this way.
function Logout() {
    let uCookie = getCookie('ActiveUser');
    $.ajax({
        type: 'POST',
        url: ProcessUrl('logout'),
        data: {
            userId: uCookie
        },
        beforeSend: function () {
            //"delete" all cookies
            var cookies = document.cookie.split(";");

            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i];
                var eqPos = cookie.indexOf("=");
                var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
            }
        },
        success: function () {
            $('.logged-in-wrapper').hide();
            $('.login-btn').show();
            $('#login #operator_un').val('');
            $('#login').modal('hide');
            window.location = ProcessUrl('?initNav');
        }
    });
};

function UIUpdate_RemoveMarcusScreens() {
    $('.for-marcus').remove();
    $('.record-inspector').remove();
    $('.email-tester').remove();
};

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
};

function CheckUserCookie() {
    let uCookie = getCookie('ActiveUser');

    if (uCookie !== '') {
        $('.login-btn').hide();
    }
};
function LoginHelper(evt) {
    if (evt.keyCode === 13) {
        $('.execute-login').trigger('click');
    }
};

function DocumentDeletionHandler() {
    //if the length of checked .del-marker-cb elements is greater than 0 then show the .delete-docs-btn button otherwise hide it
    let $delCbs = $('.del-marker-cb:checked');
    if ($delCbs.length > 0) {
        $('.delete-docs-btn').show();
    } else {
        $('.delete-docs-btn').hide();
    }
};

function FocusUserInput() {
    $('#operator_un').focus();
};

function CalculateNewMarkup(newPercent) {
    const markupAmount = (40 * (newPercent - 40)) / 100;
    const markedUpValue = 40 + markupAmount;

    return markedUpValue;
};

function AdjustSpecialMarkupUp() {
    let current = $('.special-markup-btn').text();
    let currentParsed = Number(current.replace('%', ''));
    currentParsed++;
    $('.special-markup-btn').text((currentParsed + '%'));
};
function AdjustSpecialMarkupDown() {
    let current = $('.special-markup-btn').text();
    let currentParsed = Number(current.replace('%', ''));
    currentParsed--;
    $('.special-markup-btn').text((currentParsed + '%'));
};

//chatgpt refactored
function MoveRowUp() {
    let $btn = $(this);
    let $row = $btn.closest('.item-row');
    let isSub = $row.hasClass('sub-item');

    if (isSub) {
        // Moving a sub-item row, ensuring it stays within its parent group
        let $prevSibling = $row.prev('.item-row.sub-item');
        if ($prevSibling.length) {
            $row.insertBefore($prevSibling); // Move the sub-item up within the same parent group
        }
    } else {
        // Identify the set of elements to move (the main item row and its sub-items, if any)
        let $setToMove = $row.add($row.nextUntil('.item-row:not(.sub-item)'));

        // Moving a main item row and its sub-items
        let $targetRow = $row.prevAll('.item-row:not(.sub-item)').first(); // Target for insertion

        if ($targetRow.length) {
            // Case for moving above another main item row
            $setToMove.insertBefore($targetRow);
        } else {
            // If there's no previous main item row, no action is needed as it's already the first item
        }
    }

    UpdateItemOrdinals();
};

//chatgpt refactored
function MoveRowDown() {
    let $btn = $(this);
    let $row = $btn.closest('.item-row');
    let isSub = $row.hasClass('sub-item');

    if (isSub) {
        // Moving a sub-item row, ensuring it stays within its parent group
        let $nextSibling = $row.next('.item-row.sub-item');
        if ($nextSibling.length) {
            $row.insertAfter($nextSibling); // Move the sub-item down within the same parent group
        }
    } else {
        // Identify the set of elements to move (the main item row and its sub-items, if any)
        let $setToMove = $row.add($row.nextUntil('.item-row:not(.sub-item)'));

        // Find the next main item row after the current item and its sub-items
        let $nextMainRow = $setToMove.last().nextAll('.item-row:not(.sub-item)').first();

        if ($nextMainRow.length) {
            // If there's a next main item, we find if it has sub-items to determine the correct insertion point
            let $nextMainSubItems = $nextMainRow.nextUntil('.item-row:not(.sub-item)');
            if ($nextMainSubItems.length) {
                // If the next main row has sub-items, insert after the last sub-item of the next main row
                $setToMove.insertAfter($nextMainSubItems.last());
            } else {
                // If the next main row has no sub-items, insert directly after the next main row
                $setToMove.insertAfter($nextMainRow);
            }
        }
        // If there's no next main item, no action is needed as it's already the last item
    }

    UpdateItemOrdinals();
};

function UpdateItemOrdinals() {
    let ord = 1;
    let idArr = [];
    let ordArr = [];
    let itypeArr = [];

    let iTypebase = 'JOB';
    if (window.location.href.toUpperCase().indexOf('QUOTE') > -1) {
        iTypebase = 'QUOTE';
    }
    $('.item-row').each(function () {
        let $row = $(this);
        $row.find('.ordinal-display').html('Item ' + ord);
        let $inp = $row.find('.itemordinal');
        $inp.val(ord);
        idArr.push($row.attr('data-record-id'));
        ordArr.push(ord);
        if ($row.hasClass('o-item-row')) {
            itypeArr.push(('O-' + iTypebase));
        } else {
            itypeArr.push(iTypebase);
        }
        ord++;
    });

    console.log(idArr);
    console.log(ordArr);
    console.log(itypeArr);

    $.ajax({
        type: 'POST',
        url: ProcessUrl('update-item-ordinals'),
        data: {
            itemIds: idArr,
            ordinals: ordArr,
            itemtypes: itypeArr
        }
    });
};

function ShowCalcSpinner() {
    $('.pricing-wrapper').addClass('no-pointer-events');
    document.getElementById('spinner').style.display = 'flex';
};

function HideCalcSpinner() {
    $('.pricing-wrapper').removeClass('no-pointer-events');
    document.getElementById('spinner').style.display = 'none';
};

function createInput(key, value, containerId = 'jsonFields', prefix = 'default') {
    //replace spaces with underscores
    key = key.replace(/\s+/g, '_');

    var container = document.getElementById(containerId);
    var input = document.createElement("input");
    var label = document.createElement("label");
    var regex = new RegExp(prefix + "\.", "g");  // Use RegExp to dynamically replace the prefix
    var readableKey = key.replace(/_/g, " ").replace(regex, ""); // Now using the regex
    label.innerText = readableKey + ": ";
    input.type = "text";
    input.name = key;
    input.value = value;
    input.setAttribute('data-original-name', key);

    container.appendChild(label);
    container.appendChild(input);
    container.appendChild(document.createElement("br"));
}

function processObject(obj, prefix = '') {
    for (var key in obj) {
        if (obj.hasOwnProperty(key) && obj[key] !== null && typeof obj[key] === 'object') {
            processObject(obj[key], prefix + key + '.');
        } else {
            createInput(prefix + key, obj[key]);
        }
    }
}

// Function to get a specific cookie by name
function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length === 2) return parts.pop().split(";").shift();
};

function ToggleQuoteJobField() {
    let $btn = $(this);
    let value = $btn.attr('value');
    if (value === 'job') {
        $('.navbar-job-lookup').show();
        $('.navbar-quote-lookup').hide();
    }
    else {
        $('.navbar-job-lookup').hide();
        $('.navbar-quote-lookup').show();
    }
};

function SaveSideMenuState() {
    const userId = getCookie('ActiveUser');
    if (!userId) return;

    const state = {
        config: {
            isOpen: !$('body').hasClass('sidenav-open')
        }
    };

    localStorage.setItem(`sideMenuState_${userId}`, JSON.stringify(state));
};

function GetSideMenuState() {
    const userId = getCookie('ActiveUser');
    if (!userId) return;

    const state = JSON.parse(localStorage.getItem(`sideMenuState_${userId}`)) || {
        config: {
            isOpen: true
        }
    };

    return state;
};

function SetSideMenuState(state) {
    if (!state) {
        state = GetSideMenuState();
    }

    try {
        if (state.config.isOpen) {
            openNav();
        } else {
            closeNav();
        }
    } catch (e) {
        //not defined, which is ok
        console.log('Sidenav config not set');
    }
}

function GoToHomepage() {
    window.location = ProcessUrl('');
};

function GoToRecordInspector() {
    window.location = ProcessUrl('record-inspector');
};

function GoToMarcus() {
    window.location = ProcessUrl('Administration/MarcusAdminScreen');
};

function TestEmail() {
    window.location = ProcessUrl('email-tester');
}

function ChangeDetected(from, to) {
    console.log('Field has been changed');
    console.log('From: ' + from);
    console.log('To: ' + to);

    //ShowSaveButton();
}

function ChangeDetector() {
    let $ele = $(this);
    comparerBase = $ele.val();
};

function ChangeDetectorCheck() {
    let $ele = $(this);
    let val = $ele.val();

    if (val !== comparerBase) {
        ChangeDetected(comparerBase, val);
    }
};

function LoadBugForm() {
    $.ajax({
        type: 'GET',
        url: ProcessUrl('bug-report'),
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('#bug_modal .modal-body').html(res.html);
            } catch (e) { }
        }
    });
};

function LoadFeatureRequestForm() {
    $.ajax({
        type: 'GET',
        url: ProcessUrl('feature-request'),
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('#feature_request_modal .modal-body').html(res.html);
            } catch (e) { }
        }
    });
};

$(function () {
    CheckUserCookie();
    String.prototype.format = String.prototype.f = function () {
        var s = this,
            i = arguments.length;

        while (i--) {
            s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
        }
        return s;
    };

    //console.log('Making modals draggable..');
    $('.modal-dialog').draggable({
        handle: '.modal-header'
    });

    //console.log('ajax for user status...');
    $.ajax({
        type: 'GET',
        url: ProcessUrl('user-status'),
        success: function (data) {
            try {
                var res = JSON.parse(data);

                if (!res.isMarcus) {
                    UIUpdate_RemoveMarcusScreens();
                } else {
                    $('.record-inspector').removeClass('d-none');
                    $('.email-tester').removeClass('d-none');
                }
            } catch (exception) { }
        }
    });
    //permissions
    // Get the data-permissions attribute value from the cookie
    var permissionsCookie = getCookie("Permissions");

    //console.log('checking permissions cookie');
    if (permissionsCookie) {
        // Parse the permissionsCookie two characters at a time
        var permissions = [];
        for (var i = 0; i < permissionsCookie.length; i += 2) {
            permissions.push(permissionsCookie.substr(i, 2));
        }

        // Select all elements with [data-permissions] attribute
        var elements = $("[data-permissions]");

        // Loop through elements and remove those not in the permissions array
        elements.each(function () {
            var elementPermission = $(this).attr("data-permissions");
            if (!permissions.includes(elementPermission)) {
                $(this).remove();
            } else {
                $(this).show();
            }
        });

        //console.log('updating login button displays');
        $('.logout-btn').addClass('logged-in');
        $('.login-btn').addClass('logged-in');
    } else {
        //console.log('updating login button displays');
        $('.login-btn').addClass('logged-out');
        $('.logout-btn').addClass('logged-out');
        $('.login-btn').show();
        $('.logout-btn').hide();
        $('[data-permissions]').remove();
    }

    //console.log('navbar job lookup autocomplete init');
    $('.navbar-job-lookup').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: ProcessUrl("AutocompleteJobNumber"),
                type: 'GET',
                data: {
                    'q': request.term
                },
                success: function (data) {
                    let d = JSON.parse(data);

                    response($.map(d, function (item) {
                        return { label: item.JobNumber, value: item.JobNumber, recordId: item.Id }
                    }));
                }
            });
        },
        select: function (event, ui) {
            let recordId = ui.item.recordId;
            window.location = (ProcessUrl('Job/Edit/') + recordId);
        },
        position: {
            my: "left top+20",
            at: "left bottom", // Adjust the position 20px downward
            collision: "none"
        }
    });

    //console.log('navbar quote lookup autocomplete init');
    $('.navbar-quote-lookup').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: ProcessUrl("AutocompleteQuoteNumber"),
                type: 'GET',
                data: {
                    'q': request.term
                },
                success: function (data) {
                    let d = JSON.parse(data);

                    response($.map(d, function (item) {
                        return { label: item.JobNumber, value: item.JobNumber, recordId: item.Id }
                    }));
                }
            });
        },
        select: function (event, ui) {
            let recordId = ui.item.recordId;
            window.location = (ProcessUrl('Quote/Edit/') + recordId);
        },
        position: {
            my: "left top+20",
            at: "left bottom", // Adjust the position 20px downward
            collision: "none"
        }
    });

    //console.log('Setting side menu state...');
    SetSideMenuState();
})
    .on('click', '[data-modal-to-open]', OpenModal)
    .on('click', '[data-modal-to-close]', CloseModal)
    .on('click', 'table .remove-btn', RemoveFromTable)
    .on('click', '.toast-view-button', JobDisplayViewJob)
    .on('click', '.toast-job-ticket-button', JobDisplayViewTicket)
    .on('click', '.toast-edit-job-button', JobDisplayEditJob)
    .on('click', '.toast-delivery-ticket-button', JobDisplayGetDeliveryTicket)
    .on('click', '.led-select:not(.locked)', LedSelect)
    .on('click', '.remove-link', RemoveParent)
    .on('click', '.remove-link-li', RemoveParentListItem)
    .on('click', '.execute-login', Login)
    .on('click', '.logout-btn', Logout)
    .on('keyup', '#operator_pcode', LoginHelper)
    .on('click', '.del-marker-cb', DocumentDeletionHandler)
    .on('shown.bs.modal', '#login', FocusUserInput)
    .on('click', '.special-markup-up-btn', AdjustSpecialMarkupUp)
    .on('click', '.special-markup-down-btn', AdjustSpecialMarkupDown)
    .on('click', '.move-up-btn', MoveRowUp)
    .on('click', '.move-down-btn', MoveRowDown)
    .on('click', 'input[name="quoteJobRadio"]', ToggleQuoteJobField)
    .on('click', '.navbar-brand', GoToHomepage)
    .on('click', '.record-inspector button', GoToRecordInspector)
    .on('click', '.for-marcus button', GoToMarcus)
    .on('click', '.email-tester button', TestEmail)
    .on('show.bs.modal', '#bug_modal', LoadBugForm)
    .on('show.bs.modal', '#feature_request_modal', LoadFeatureRequestForm)
    .on('click', '.submit-bug-btn', SubmitBug);
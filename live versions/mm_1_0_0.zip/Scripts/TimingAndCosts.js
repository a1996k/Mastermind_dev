﻿var breakdown = new Array();
var timing = new Array();
var newBreakdown = new Array();
var newBreakdownTotals = new Array();

function HasValidDuration(el) {
    let validDuration =
        typeof el !== 'undefined' &&
        el !== null &&
        el !== "0.00" &&
        el != "0" &&
        el != 0;

    return validDuration;
}

function ClearBreakdownList() {
    $('#pricing_breakdown_modal .modal-body ul').html('');
};

function ClearPriceAndCostList() {
    $('#cost_comparison_modal .modal-body ul').html('');
};

function StylizeBreakdownTable() {
    const list = document.querySelector('#cost_comparison_modal .modal-body ul');
    const items = Array.from(list.querySelectorAll('li[data-grouper]'));

    let groups = {};

    // Group items by data-grouper for DOM manipulation
    items.sort((a, b) => a.getAttribute('data-grouper').localeCompare(b.getAttribute('data-grouper'))); // Sort items if needed
    items.forEach(item => {
        let group = item.getAttribute('data-grouper');
        if (!groups[group]) {
            groups[group] = { elements: [], ordinal: Number.MAX_SAFE_INTEGER };
        }
        groups[group].elements.push(item);
    });

    // Append detailed total rows using newBreakdownTotals data
    Object.keys(groups).sort((a, b) => groups[a].ordinal - groups[b].ordinal).forEach(group => {
        let data = groups[group];
        let totalData = newBreakdownTotals.find(total => total.ItemId.toString() === group);
        if (totalData && data.elements.length > 0) {
            let lastElement = data.elements[data.elements.length - 1];
            let priceId = lastElement.querySelector('.row').getAttribute('data-price-id'); // Get data-price-id from the last element

            let totalItem = document.createElement('li');
            totalItem.classList.add('total');
            totalItem.setAttribute('data-record-id', totalData.ItemId);
            totalItem.setAttribute('data-grouper', group);
            totalItem.innerHTML =
                `<div class="container">
                <div class="row" data-price-id="${priceId}"> <!-- Preserve data-price-id -->
                    <div class="col">
                        ${"Totals"}
                    </div>
                    <div class="col">
                        ${Number(totalData.Duration).toFixed(2)}
                    </div>
                    <div class="col">
                        ${Number(totalData.Cost).toFixed(2)}
                    </div>
                    <div class="col">
                        <input type="text" class="markup-val fs-4" value="${totalData.Markup}" />
                    </div>
                    <div class="col">
                        ${Number(totalData.Price).toFixed(2)}
                    </div>
                    <div class="col">
                    </div>
                </div>
            </div>`;
            data.elements[data.elements.length - 1].after(totalItem);
            data.elements.push(totalItem); // Add the total item to the group for later reordering
        }
    });

    // Clear the existing list and reappend items in the correct order including totals
    list.innerHTML = '';
    Object.keys(groups).sort((a, b) => groups[a].ordinal - groups[b].ordinal).forEach(group => {
        groups[group].elements.forEach(item => list.appendChild(item));
    });

    // Append a header row before the first item
    let header = document.createElement('li');
    header.classList.add('header');
    header.innerHTML =
        `<div class="container">
                <div class="row">
                    <div class="col">
                    </div>
                    <div class="col">
                        ${"Duration/Quantity"}
                    </div>
                    <div class="col">
                        ${"Cost"}
                    </div>
                    <div class="col">
                        ${"Markup"}
                    </div>
                    <div class="col">
                        ${"Price"}
                    </div>
                    <div class="col">
                        ${"Difference"}
                    </div>
                </div>
            </div>`;
    list.prepend(header);
};

function ShowPriceAndCost() {
    $('#cost_comparison_modal .modal-body ul').append(
        `<li>
            <div class="container">
                <div class="row">
                    <div class="col">Reason for Cost</div>
                    <div class="col">Service Time</div>
                    <div class="col">Cost</div>
                    <div class="col">Markup</div>
                    <div class="col">Price</div>
                    <div class="col">Difference</div>
                </div>
            </div>
        </li>`
    );

    newBreakdown.sort((a, b) => a.priceListOrdinal - b.priceListOrdinal);

    for (let i = 0; i < newBreakdown.length; i++) {
        let totalPrice = Number(newBreakdown[i].price).toFixed(2);
        let totalCost = Number(newBreakdown[i].cost).toFixed(2);
        let durationOrQuantity = "";

        if (HasValidDuration(newBreakdown[i].duration)) {
            durationOrQuantity = `${newBreakdown[i].stringTime} (${newBreakdown[i].duration})`;
        } else {
            durationOrQuantity = newBreakdown[i].quantity;
        }

        $('#cost_comparison_modal .modal-body ul').append(
            `<li data-record-id="${newBreakdown[i].dbPriceId}" data-grouper="${newBreakdown[i].itemId}">
            <div class="container">
                <div class="row" data-price-id=${newBreakdown[i].dbPriceId}>
                    <div class="col">${newBreakdown[i].title}</div>
                    <div class="col">${durationOrQuantity}</div>
                    <div class="col">${totalCost === "0.00" ? "-" : totalCost}</div>
                    <div class="col markup-col"><input type="text" class="markup-val fs-4" value="${newBreakdown[i].markup}" /></div>
                    <div class="col">${totalPrice === "0.00" ? "-" : totalPrice}</div>
                    <div class="col">${(totalPrice - totalCost).toFixed(2) === "0.00" ? "-" : (totalPrice - totalCost).toFixed(2)}</div>
                </div>
            </div>
        </li>`
        );
    }

    $('#cost_comparison_modal .modal-body ul li').each(function () {
        var $el = $(this);
        let num = parseInt($el.attr('data-record-id'));

        if (num === 0) {
            $el.find('input.markup-val').prop('disabled', true);
        }
    });

    StylizeBreakdownTable();

    $('#cost_comparison_modal').modal('show');
};

function UpdatePricingDisplay() {
    $('.price').html('');

    //append the item totals to the display
    for (var i = 0; i < newBreakdownTotals.length; i++) {
        $('.price').append(`<div data-jump-to-id="${newBreakdownTotals[i].ItemId}">Item ${newBreakdownTotals[i].Ordinal}: $${newBreakdownTotals[i].Price}</div>`);
        //$('.price').append('<div>Item ' + newBreakdownTotals[i].Ordinal + ': $' + newBreakdownTotals[i].Price + '</div>');
    }
};

/* end pricing ui functions */

function New_AddAmount(cost, markup, price, duration, title, itemId, quantity, dbPriceId, stringTime, priceListOrdinal) {
    newBreakdown.push({
        cost,
        markup,
        price,
        duration,
        title,
        itemId,
        quantity,
        dbPriceId,
        stringTime,
        priceListOrdinal
    });
};

function New_AddItemTotal(cost, price, markup, duration, itemId, itemOrdinal, isOutsourced, stringTime) {
    newBreakdownTotals.push(
        {
            Cost: cost,
            Markup: markup,
            Price: price,
            Duration: duration,
            ItemId: itemId,
            Ordinal: itemOrdinal,
            IsOutsourced: isOutsourced,
            StringTime: stringTime
        }
    )
};

/* pricing logic functions */

function PerformCalcs() {
    console.log('PerformCalcs()');
    let recordtype = '';
    let url = window.location.href;
    var isQuote = url.toLowerCase().includes('quote') || url.includes('-quote-');
    var isJob = url.toLowerCase().includes('job') || url.includes('-job-');
    let recordId = -1;

    newBreakdown = new Array();

    recordId = $('#Id').val();

    if (isQuote) {
        recordtype = "QUOTE";

        if (typeof recordId === 'undefined') {
            recordId = $('#VM_Quote_Quote_Id').val();
        }
    }

    if (isJob) {
        recordtype = "JOB";

        if (typeof recordId === 'undefined') {
            recordId = $('#VM_Job_Job_Id').val();
        }
    }

    $.ajax({
        type: 'POST',
        url: ProcessUrl('run-calcs-alt'),
        data: {
            recordtype: recordtype,
            recordId: recordId
        },
        beforeSend: ShowCalcSpinner,
        success: function (data) {
            try {
                let res = JSON.parse(data);
                //reset breakdown array
                newBreakdown = new Array();

                for (var i = 0; i < res.itemized.length; i++) {
                    New_AddAmount(
                        res.itemized[i].Cost,
                        res.itemized[i].Markup,
                        res.itemized[i].Price,
                        res.itemized[i].Duration,
                        res.itemized[i].Title,
                        res.itemized[i].ItemId,
                        res.itemized[i].Quantity,
                        res.itemized[i].Id,
                        res.itemized[i].StringTime,
                        res.itemized[i].PriceListOrdinal
                    );
                }

                //for each item total
                newBreakdownTotals = new Array();
                for (var i = 0; i < res.totals.length; i++) {
                    New_AddItemTotal(
                        res.totals[i].Total_Cost,
                        res.totals[i].Total_Price,
                        res.totals[i].Item_Markup,
                        res.totals[i].Total_Duration,
                        res.totals[i].QuoteItem ?? res.totals[i].JobItem,
                        res.totals[i].Ordinal,
                        res.totals[i].IsOutsourced,
                        res.totals[i].String_Time
                    );
                }

                UpdatePricingDisplay();

                for (let i = 0; i < res.additionalData.length; i++) {

                    var $row = $('.item-row[data-record-id="' + res.additionalData[i].Id + '"]');
                    ReRenderRowServices(res.additionalData[i].Id);
                    $row.find('.stock-row').find('.run-size').html(res.additionalData[i].RunLength + ' x ' + res.additionalData[i].RunWidth);
                    $row.find('.calced-up-val').html(res.additionalData[i].Up);
                    $row.find('.total-sheets').html(res.additionalData[i].Sheets);
                    if (isQuote) {
                        $row.find('#QuoteItem_RunLength').val(res.additionalData[i].RunLength);
                        $row.find('#QuoteItem_RunWidth').val(res.additionalData[i].RunWidth);
                    }
                    else {
                        $row.find('#JobItem_RunLength').val(res.additionalData[i].RunLength);
                        $row.find('#JobItem_RunWidth').val(res.additionalData[i].RunWidth);
                    }
                    $row.find('.sheets-display').html(res.additionalData[i].Sheets);
                    $row.find('.scrap-sheets-display').html(Number(additionalData[i].ScrapSheets));
                    if (typeof res.additionalData[i].RunSheets === 'undefined') {
                        $row.find('.run-sheets-display').html('N/A');
                    } else {
                        $row.find('.run-sheets-display').html(Number(res.additionalData[i].RunSheets));
                    }
                }
            } catch (e) { }
        },
        complete: HideCalcSpinner
    });
};

function JumpToItem() {
    let rId = $(this).attr('data-jump-to-id');
    let $tgt = $(`.item-row[data-record-id="${rId}"]`);

    $('html, body').animate({
        scrollTop: $tgt.offset().top - 300
    }, 1000);
};

//new
function SubmitMarkupOverride(evt) {
    let $el = $(this);
    let isItemTotal = $el.parents('li').hasClass('total');
    let groupId = $el.parents('li').attr('data-grouper');
    let recordType = '';

    let dbPriceId = $el.parents('.row').attr('data-price-id');

    let recType2 = 'quote';
    if (window.location.href.indexOf('Job') > -1) {
        recType2 = "job";
    }

    if (isItemTotal) {
        recordType = "Item";
    }

    if (evt.keyCode === 13) {
        //get the id and the new value
        let rId = $el.parents('li').attr('data-record-id');
        let val = $el.val();

        //ajax to back end

        $.ajax({
            type: 'POST',
            url: ProcessUrl('override-specific-markup'),
            data: {
                recordId: rId,
                val: val,
                recType2
            },
            success: function () {
                //not working but i cant fucking care right now because this place is full of double-standards
                if (recType2 === 'Item') {
                    $('#cost_comparison_modal li[data-grouper="' + groupId + '"]:not(.total)').each(function () {
                        var $e = $(this).find('input');
                        $e.val(val);
                    });
                }
            }
        });
    }
};

/*end pricing logic functions */

$(function () {
    //if we're on a page with Quote or Job in the url, show the pricing wrapper
    // Sample URL
    const url = window.location.href;

    // Regular expression pattern with the 'i' flag for case-insensitivity
    const pattern = /job|quote/i;

    if (pattern.test(url) && $('.error').length === 0) {
        $('.pricing-wrapper').removeClass('d-none');
    }
})
    .on('hide.bs.modal', '#pricing_breakdown_modal', ClearBreakdownList)
    .on('hide.bs.modal', '#cost_comparison_modal', ClearPriceAndCostList)
    .on('click', '.calc-info', ShowPriceAndCost)
    .on('keyup', 'input.markup-val', SubmitMarkupOverride)
    .on('click', 'div[data-jump-to-id]', JumpToItem);
﻿var datePicker;

function DashboardNav() {
    let $btn = $(this);
    let currentView = $('.dashboard-button.db-selected').attr('value');
    $('.metric-menu-wrapper[data-menu-name="' + currentView + '"]').fadeOut('fast');
    $('.dashboard-button.db-selected').removeClass('db-selected');

    let newView = $btn.attr('value');
    $btn.addClass('db-selected');
    $('.metric-menu-wrapper[data-menu-name="' + newView + '"]').fadeIn('fast');

    LoadCardsForNewView(newView);
};

function LoadDashboardCard(ajaxId, viewName) {
    let $card = $('.ajaxable[data-ajax-id="' + ajaxId + '"]');
    let isLocked = $card.find('input[name="Locked"]').is(':checked');
    let selectedInterval = $card.find('select[name="Range"] option:selected').text();
    let $loader = $card.find('.loader');

    if (selectedInterval === '') {
        selectedInterval = 'Days';
    }

    //arr for users
    //if we have a data-user-restrict-id on the current tab, restrict results to that user
    //otherwise push -1 which would indicate all users should be retrieved
    let userArr = new Array();
    let indUserId = $('.db-selected').attr('data-user-restrict-id');

    //push the specific id otherwise -1 (for all) onto the array. data-user-restrict-id exists on the individual tab of any Role = User
    if (indUserId) {
        userArr.push(indUserId);
    } else {
        userArr.push(-1);
    }

    let clientArr = new Array();

    if ($('#all_clients_box').length) {
        if ($('#all_clients_box').is(':checked')) {
            clientArr.push("-1");
        } else {
            $('input[name="SelectedOptions"]:checked').each(function () {
                clientArr.push($(this).attr('data-option-value'));
            });
        }
    }
    else {
        clientArr.push("-1");
    }

    $.ajax({
        type: 'POST',
        beforeSend: function () {
            $loader.show();
        },
        url: ProcessUrl('get-dashboard-card'),
        data: {
            clients: clientArr,
            users: userArr,
            tabName: viewName,
            ajaxId: ajaxId,
            start: rangeStart,
            end: rangeEnd,
            isLocked: isLocked ?? false,
            userRangeOverride: selectedInterval
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $card.find('.card-data-wrapper').html(res.Html);
                Charts(ajaxId, res.Records, res.UserTotals);
            } catch (e) { }
        },
        complete: function () {
            $loader.hide();
        }
    });
};

function LoadCardsForNewView(viewName) {
    $('.metric-menu-wrapper[data-menu-name="' + viewName + '"] .ajaxable').each(function (index, element) {
        LoadDashboardCard($(element).attr('data-ajax-id'), viewName);
    });
};

function LoadState() {
    const userId = getCookie('ActiveUser');
    if (!userId) return;

    const state = JSON.parse(localStorage.getItem(`dashboardState_${userId}`)) || {
        config: {
            dateRange: '',
            tab: '',
            charts: []
        }
    };

    let tabName = state.config.tab;

    $('.db-selected').removeClass('db-selected');
    $('input[value="' + tabName + '"]').addClass('db-selected');

    $('#range_filter').val(state.config.dateRange);
    $('#range_filter').trigger('change');
};

function SaveState() {
    const userId = getCookie('ActiveUser');
    if (!userId) return;

    const state = {
        config: {
            dateRange: $('#range_filter').val(),
            tab: document.querySelector('.db-selected').value,
            charts: []
        }
    };

    document.querySelectorAll('.card-data-wrapper').forEach(chart => {
        const chartParent = $(chart).parents('.ajaxable')[0];

        state.config.charts.push({
            ajaxId: $(chartParent).attr('data-ajax-id'),
            rangeOverride: $(chartParent).find('select[name="Range"]').val(),
            rangeLocked: $(chartParent).find('input[name="Locked"]').is(':checked')
        });
    });

    localStorage.setItem(`dashboardState_${userId}`, JSON.stringify(state));
};

function RefreshDashboard() {
    $('.db-selected').trigger('click');
};

function RangeSelection() {
    $(this).parent().find('input[type="checkbox"]').prop('checked', true);
};

function MultiselectCheckboxClick() {
    var selectedItems = $(this).closest('.ms-dropdown-content').find('input[type="checkbox"]:checked').map(function () {
        return this.value;
    }).get().join('<br>');

    $(this).closest('.ms-dropdown').find('.ms-dropdown-button').html(selectedItems.length > 0 ? selectedItems : 'Select options');
};

function MultiselectClick() {
    var $dropdownContent = $(this).next('.ms-dropdown-content');
    // Toggle dropdown visibility
    $dropdownContent.toggle();

    // If hiding the dropdown, send AJAX request
    if (!$dropdownContent.is(':visible')) {
        var selectedUsers = $dropdownContent.find('input[type="checkbox"]:checked').map(function () {
            return $(this).attr('data-option-value');
        }).get();
    }
};

function ToggleAllClients() {
    let $cb = $(this);
    let c = $cb.is(':checked');

    $('input[name="SelectedOptions"]:not(#all_clients_box)').prop('checked', c);
};
$(function () {
    // Initialize date range picker
    $('#range_filter').daterangepicker({
        opens: 'left',
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
    }, function (start, end, label) {
        rangeStart = start.format('YYYY-MM-DD');
        rangeEnd = end.format('YYYY-MM-DD');
        let viewName = $('.dashboard-button.db-selected').attr('value');
        LoadCardsForNewView(viewName);
    });

    //for refresher animation
    $(document).ajaxStart(function () {
        $('#range_filter').prop('disabled', true);
        $('.refresh-dashboard').off('click');
        $('.refresh-dashboard').addClass('spin');
        $('.dashboard-button').prop('disabled', true);
    });

    $(document).ajaxStop(function () {
        $('.refresh-dashboard').removeClass('spin');
        $('.refresh-dashboard').on('click', RefreshDashboard);
        $('#range_filter').prop('disabled', false);
        $('.dashboard-button').prop('disabled', false);
    });

    rangeStart = moment().format("YYYY-MM-DD");
    rangeEnd = moment().format("YYYY-MM-DD");

    $('.metric-wrapper').sortable();

    $('.db-selected').trigger('click');
})
    .on('click', '.dashboard-button', DashboardNav)
    .on('change', 'select[name="Range"]', RangeSelection)
    .on('click', 'input[name="Locked"], .dashboard-button', SaveState)
    .on('click', '.ms-dropdown-button', MultiselectClick)
    .on('click', '#all_clients_box', ToggleAllClients)
    /*.on('change', '.ms-dropdown-content input[type="checkbox"]', MultiselectCheckboxClick)*/;
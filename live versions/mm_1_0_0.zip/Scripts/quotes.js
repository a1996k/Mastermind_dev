﻿//datatable vars (not currently used?)
var qst, mst, pst;

//hotfix/hack for resetting collapses
//easier to iterate all collapse-parent items and click them then to determine which are open and iterate those (due to cur implementation)
//so, if this var is set to true and ExpandCollapseList is called, the list will only be collapsed (hidden). It will not be expanded (shown).
//note: the expand/collapse is actually d-none functionality and bs collapse
var resetting = false;

//hotfix/hack for opening necessary collapsed
//when a select service button is clicked, we need to select all currently selected services (for user convenience)
//we also need to expand the collapsed lists, so the user can see the checked boxes.
//if configging is true and ExpandCollapseList is called, only lists with checked boxes will be shown.
var configging = false;

//hotifx/hack for view layout functionality
//if this is true, redirect to the layout edit view after saving the quote
//if this is false, redirect to the service arrangement view after saving the quote
var viewingLayout = false;

//hotfix/hack for saving record
//if true, just save and nothing else
var justSaving = false;

var tempNotes = new Array();
var $activeServiceItem;

var doingCalcs = false;

function ConvertFormattedToDecimal() {
    //get the formatted time
    //ajax request for decimal time

    var fTime = $('input[name="ServiceTimeEditor.FormattedServiceTime"]').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('formatted-time-to-decimal'),
        data: {
            'formattedTime': fTime
        },
        success: function (data) {
            try {
                //res is not used; just to see if the data is valid JSON
                let res = JSON.parse(data);
                $('input[name="ServiceTimeEditor.ServiceTime"]').val(data);
            } catch (e) {
                $('input[name="ServiceTimeEditor.ServiceTime"]').val('');
            }
        }
    });
};
function ConvertServiceTimeToFormatted() {
    //get the service time
    //ajax request for formatted time
    //set the formatted time
    var dTime = $('input[name="ServiceTimeEditor.ServiceTime"]').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('decimal-time-to-formatted'),
        data: {
            'decimalTime': dTime
        },
        success: function (data) {
            $('input[name="ServiceTimeEditor.FormattedServiceTime"]').val(data);
        }
    });
};

function LoadMaterials() {
    let $cat = $(this);
    let rId = $cat.attr('data-record-id');

    $.ajax({
        type: 'GET',
        url: ProcessUrl('load-materials-by-category' + '/' + rId),
        success: function (data) {
            try {
                let res = JSON.parse(data);
                console.log(res);

                // Assuming the table has an id of 'materialsTable'
                let $table = $('#materials_select_table');

                // Destroy any existing DataTable to reinitialize it later
                if ($.fn.DataTable.isDataTable($table)) {
                    $table.DataTable().destroy();
                }

                // Empty the table body
                $table.find('tbody').empty();

                // Iterate through the result and insert rows
                for (let i = 0; i < res.length; i++) {
                    let rowHtml =
                        `
                            <tr class="admin-edit-item-material"
                                data-material-size="${res[i].Size}"
                                data-item-title="${res[i].Title}"
                                data-record-id="${res[i].Id}"
                                data-mat-cost-val="${res[i].Cost}"
                                data-mat-cost-formatted="${res[i].CostFormatted}"
                                data-mat-cost-unit="${res[i].CostType}">
                                <td>
                                    <a href="javascript:void(0);" class="material-title">${res[i].Title}</a>
                                </td>
                                <td>

                                </td>
                                <td>
                                    ${res[i].Size}
                                </td>
                                <td>
                                    ${res[i].Stock}
                                </td>
                                <td>
                                    ${res[i].Cost}
                                </td>
                            </tr>
                        `;
                    $table.find('tbody').append(rowHtml);
                }
                // Reinitialize DataTable
                $table.DataTable();
            } catch (e) {
                console.error('Error processing materials data:', e);
            }
        }
    })
};

function AddButtonHandler() {
    var checkedItems = $('#materials_select input[type="checkbox"]:checked').length;

    if (checkedItems > 0) {
        $('.ps-add-btn').prop('disabled', false);
    } else {
        $('.ps-add-btn').prop('disabled', true);
    }
};

function AddItem() {
    var masterQuoteId = $('#VM_Quote_Quote_Id').val();

    $.get((ProcessUrl('add-item/quote/') + masterQuoteId), function (data) {
        $('#job_items').append(JSON.parse(data));
        NonTableRowRemoveAddHandler();
    });
};

function AddOutsourcedItem() {
    var masterQuoteId = $('#VM_Quote_Quote_Id').val();

    $.get((ProcessUrl('add-outsourced-item/quote/') + masterQuoteId), function (data) {
        $('#job_items').append(JSON.parse(data));
    });
};

function RemoveItem() {
    var $btn = $(this);
    var $row = $btn.parents('.item-row');
    var rowId = $row.attr('data-record-id');
    var isOutsource = $btn.hasClass('remove-os-btn');

    $.post((ProcessUrl('remove-item/quote/') + rowId + '/' + isOutsource), function () {
        $row.remove();
        NonTableRowRemoveAddHandler();
    });
};

function CreateServiceSelect(prodId) {
    //creates an id like service_select_{prodId}_{# instance of this product}
    var newId = ('service_select_' + prodId + '_' + ($('div[id^="service_select_' + prodId + '"]').length + 1)).toString();

    //create a new div with id newId inside of #service_select_forms
    $('#service_select_form').append('<div id="' + newId + '" class="service-select-form"></div>');

    $.ajax({
        type: 'GET',
        url: ProcessUrl('Services/Get/All'),
        success: function (data) {
            $('#' + newId).html(data);
        }
    });
};

//these should be events on modal shown/hide
function SelectServices() {
    var sid = $(this).parents('.item-row').attr('data-record-id');
    $('#sp_adder_helper').val(sid);
};

function SelectMaterials() {
    var pid = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(pid);
};

function SelectPresses() {
    var pid = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(pid);
};

function CustomFormSerialization(evt) {
    evt.preventDefault();
    $('.client-autocomplete').prop('disabled', true);
    //declare a new array for the objects (serializing the items)
    var arr = [];
    var oArr = [];
    var index = 1;

    //Validator.js
    CheckFormValidation();

    //failedValidation is declared in Validator.js
    if (!failedValidation) {
        $('.o-item-row').each(function () {
            var $oRow = $(this);
            var obj = {};

            obj['Id'] = $oRow.attr('data-record-id');
            obj['Quote'] = $oRow.find('.quote-id').val();
            obj['Description'] = $oRow.find('.item-description').html();
            obj['Notes'] = $oRow.find('.item-notes').html();
            obj['ShippingCost'] = $oRow.find('.shipping-cost').val();
            obj['JobCost'] = $oRow.find('.job-cost').val();
            obj['Vendor'] = $oRow.find('.vendor').val();
            obj['Quantity'] = $oRow.find('.o-item-qty').val();
            obj['JobPriceUnit'] = $oRow.find('.job-price-unit').val();

            oArr.push(obj);
        });
        $('.quote-item-row').each(function () {
            var $row = $(this);
            var obj = {};
            let speedUnit = $row.find('.selected-press-speed-display .speed-unit').html().trim();
            $('#print_speed_ref_sl option').each(function () {
                var $option = $(this);
                if ($option.text().trim() == speedUnit) {
                    $option.prop('selected', true);
                }
            });
            obj['Id'] = $row.attr('data-record-id');
            //set the Title property of obj to the value contained in QuoteItems.Title
            obj['Title'] = $row.find('.item-title').val();
            obj['Quantity'] = $row.find('.item-quantity').val();
            obj['Width'] = $row.find('.item-width').val();
            obj['Length'] = $row.find('.item-length').val();
            obj['Quote'] = $('input[name="VM_Quote.Quote.Id"]').val();
            obj['Material'] = $row.find('.selectedmaterial').val();
            obj['Description'] = $row.find('.item-description').val();
            obj['Notes'] = $row.find('.item-notes').val();
            obj['MaterialRunSize'] = $row.find('.current-mrs').val();
            obj['PressSpeedDenominator'] = $('#print_speed_ref_sl option:selected').val();
            obj['PressSpeedNumerator'] = $row.find('.selected-press-speed-display .speed').html().trim();
            obj['Press'] = $row.find('.selectedpress').val();
            obj['Up'] = $row.find('.calced-up-val').html().trim();
            obj['QuantityBy'] = $row.find('.item-quantity-by').val();
            obj['TotalQuantity'] = (obj['Quantity'] * obj['QuantityBy']);
            obj['UserSheetOverride'] = $row.find('.user-sheet-override').val();
            obj['InternalNotes'] = $row.find('.internal-notes').val();
            obj['UpValueLocked'] = $row.find('.up-value-locked').is(':checked');
            obj['TotalScrapSheets'] = $row.find('.total-scrap-sheets').html();
            obj['SelectedSpeed'] = $row.find('.selected-speed').val();
            obj['MaterialNotes'] = $row.find('.chosen-material-notes .material-notes').val();
            obj['ScrapSheets'] = $row.find('.item-scrap-sheets').val();
            obj['DesignHours'] = $row.find('.design-hours').val();
            obj['ArtworkProvided'] = !($row.find('.artwork-provided').is(':checked'));

            // Create an empty array variable to store the combined list items
            var combinedList = [];

            $row.find('.service-list li').each(function () {
                combinedList.push($(this));
            });

            //create a new array for the services
            var services = [];

            for (var i = 0; i < combinedList.length; i++) {
                let serObj = {};
                serObj['OriginalService'] = combinedList[i].attr('data-record-id');
                serObj['Id'] = combinedList[i].attr('data-record-id');
                serObj['QuoteItemId'] = $row.attr('data-record-id');
                serObj['Ordinal'] = (i + 1);
                serObj['IsCuttingService'] = $(combinedList[i]).find('.is-cutting-service').val();
                services.push(serObj);
            }

            obj['QuoteItemServices'] = services;

            arr.push(obj);
        });

        var form = $('#quote_builder').serializeArray();
        let formParsed = {};
        $.each(form, function (index, field) {
            formParsed[field.name.replace('VM_Quote.Quote.', '')] = field.value;
        });
        formParsed['MarkupOverride'] = Number(($('.special-markup-btn').html().trim()).replace('%', '')) / 100.0000;
        formParsed['IsPickup'] = $('#rad_pickup').is(':checked');
        formParsed['ShippingMethod'] = $('#VM_Quote_Quote_ShippingMethod').val();
        formParsed['IsWarehouseJob'] = $('#VM_Quote_Quote_IsWarehouseJob_Value').is(':checked');
        formParsed['IsGolfEvent'] = $('#VM_Quote_Quote_IsGolfEvent_Value').is(':checked');

        $.ajax({
            type: 'POST',
            url: ProcessUrl('Quote/Update'),
            data: {
                q: formParsed,
                items: arr,
                outsourcedItems: oArr,
                tempNotes: tempNotes
            },
            complete: function (data) {
                try {
                    let res = JSON.parse(data.responseJSON);

                    for (var i = 0; i < res.length; i++) {
                        let curId = res[i].Id;
                        let curUp = res[i].Up;
                        let $curRow = $('.quote-item-row[data-record-id="' + curId + '"]');
                        //update the up value display as well as the hidden field
                        $curRow.find('.calced-up-val').html(curUp);
                        $curRow.find('.item-up-val').val(curUp);
                    }

                    if (doingCalcs) {
                        doingCalcs = false;
                        PerformCalcs();
                    }
                } catch (e) { /*console.log(e);*/ }
            }
        });
    } else {
        alert('Please complete the necessary fields');
    }
};

function AddPrepressServicesToItem(evt) {
    var $tgt = $(evt.target);

    var itemId = $('#sp_adder_helper').val();
    var list = $('#prepress_service_select_table tr');
    var pressDefaultHelper = $('#press_add_helper').val();
    var listDestination = '.quote-item-row[data-record-id="' + itemId + '"] .prepress-service-list';

    var arr = new Array();

    for (var i = 0; i < list.length; i++) {
        var tArr = $(list[i]).find('input[type="checkbox"][data-record-type="service"]:checked').map(function () {
            return {
                ServiceId: $(this).attr('data-service-id'),
                ServiceTitle: $(this).attr('data-item-title'),
                RecordId: 0,
                IsCuttingService: false
            };
        }).get();

        arr = [...arr, ...tArr];
    }

    var mod = { ItemServiceDetails: arr, RowId: itemId, RecordType: "quote" };

    $.ajax({
        type: 'POST',
        url: ProcessUrl('item-service-update'),
        data: {
            items: mod,
            pressId: pressDefaultHelper,
            serviceType: 'Prepress'
        },
        success: function (data) {
            try {
                var res = JSON.parse(data);

                $('#prepress_service_select_table input[type="checkbox"]:checked').prop('checked', false);

                $(listDestination).html('');
                $(listDestination).html(res.services);
            } catch (e) { }
        }
    });
};

function AddCuttingServicesToItem(evt) {
    var $tgt = $(evt.target);

    var itemId = $('#sp_adder_helper').val();
    var list = $('#cutting_service_select_table tr');
    var pressDefaultHelper = $('#press_add_helper').val();
    var listDestination = '.quote-item-row[data-record-id="' + itemId + '"] .cutting-service-list';

    var arr = new Array();

    for (var i = 0; i < list.length; i++) {
        var tArr = $(list[i]).find('input[type="checkbox"][data-record-type="service"]:checked').map(function () {
            return {
                ServiceId: $(this).attr('data-service-id'),
                ServiceTitle: $(this).attr('data-item-title'),
                RecordId: 0,
                IsCuttingService: true
            };
        }).get();

        arr = [...arr, ...tArr];
    }

    var mod = { ItemServiceDetails: arr, RowId: itemId, RecordType: "quote" };

    $.ajax({
        type: 'POST',
        url: ProcessUrl('item-service-update'),
        data: {
            items: mod,
            pressId: pressDefaultHelper,
            serviceType: 'Cutting'
        },
        success: function (data) {
            try {
                var res = JSON.parse(data);
                //console.log(res);
                $('#cutting_service_select_table input[type="checkbox"]:checked').prop('checked', false);

                $(listDestination).html('');
                $(listDestination).html(res.services);
            } catch (e) { }
        }
    });
};

function AddFinishingServicesToItem(evt) {
    var itemId = $('#sp_adder_helper').val();
    var list = $('#finishing_service_select_table tr');
    var pressDefaultHelper = $('#press_add_helper').val();
    var listDestination = '.quote-item-row[data-record-id="' + itemId + '"] .finishing-service-list';

    var arr = new Array();

    for (var i = 0; i < list.length; i++) {
        var tArr = $(list[i]).find('input[type="checkbox"][data-record-type="service"]:checked').map(function () {
            return {
                ServiceId: $(this).attr('data-service-id'),
                ServiceTitle: $(this).attr('data-item-title'),
                RecordId: 0,
                IsCuttingService: false
            };
        }).get();

        arr = [...arr, ...tArr];
    }

    var mod = { ItemServiceDetails: arr, RowId: itemId, RecordType: "quote" };

    $.ajax({
        type: 'POST',
        url: ProcessUrl('item-service-update'),
        data: {
            items: mod,
            pressId: pressDefaultHelper,
            serviceType: 'Finishing'
        },
        success: function (data) {
            try {
                var res = JSON.parse(data);
                //console.log(res);
                $('#finishing_service_select_table input[type="checkbox"]:checked').prop('checked', false);

                $(listDestination).html('');
                $(listDestination).html(res.services);
            } catch (e) {
            }
        }
    });
};

function AddMaterialToItem() {
    var $materialRow = $('#materials_select_table').find('.admin-edit-item-material.selected');
    let spAdderVal = $('#sp_adder_helper').val();
    var theSel = ('#sm_' + spAdderVal);
    let $theRow = $('.quote-item-row[data-record-id="' + spAdderVal + '"]');

    if ($materialRow.length === 0) {
        $(theSel).val('');
        $theRow.find('.selectedmaterial').val('');
        $theRow.find('.view-layout-btn').prop('disabled', true);
        $theRow.find('.calced-up-val').html('N/A');
        $theRow.find('#QuoteItem_Up').val('');
        $theRow.find('.total-sheets').html('N/A');
        $theRow.find('.total-run-sheets').html('N/A');
        return; // No material selected, do nothing
    } else {
        $theRow.find('.view-layout-btn').prop('disabled', false);
    }

    var itemTitle = $materialRow.find('.material-title').text().trim();

    var materialId = $materialRow.attr('data-record-id');
    var matSize = $materialRow.attr('data-material-size');
    var matCost = $materialRow.attr('data-mat-cost-formatted');
    var matCostUnit = $materialRow.attr('data-mat-cost-unit');
    var matSizeArr = matSize.split('x');
    var matLength = matSizeArr[0];
    var matWidth = matSizeArr[1];
    var pressId;
    var ppf, ppb;

    $.ajax({
        type: 'POST',
        url: ProcessUrl('reset-material-values-on-item'),
        data: {
            'id': $('#sp_adder_helper').val(),
            'itemType': 'quote',
            'materialId': materialId
        },
        success: function (data) {
            try {
                var res = JSON.parse(data);
                matCost = res.MaterialCostFormatted;
                matCostUnit = res.MatCostUnit;
                pressId = res.PressId;
                ppf = res.ColorFrontProfile;
                ppb = res.ColorBackProfile;
            } catch (e) { }
        },
        complete: function () {
            let $theRow = $('.quote-item-row[data-record-id="' + spAdderVal + '"]');
            //set run size values
            $theRow.find('.material-run-size-w').val(matWidth);
            $theRow.find('.material-run-size-l').val(matLength);
            //set the run size display
            $theRow.find('.run-size').html(matLength + ' x ' + matWidth);
            //set the material name display
            $theRow.find('.material-name').html(itemTitle);
            $theRow.find('.sheets-display').html('-');
            $theRow.find('.scrap-sheets-display').html('-');
            $theRow.find('.run-sheets-display').html('-');
            //show the cost and unit
            $theRow.find('.selected-material-cost').html(matCost);
            $theRow.find('.selected-material-cost-unit').html(matCostUnit);

            $theRow.find('.front-color-display').html(ppf);
            $theRow.find('.back-color-display').html(ppb);

            var $selectedPressInput = $('.quote-item-row[data-record-id="' + spAdderVal + '"] .selectedpress');
            $selectedPressInput.val(pressId);

            $(theSel).val(materialId);

            $theRow.find('.up-up-btn').prop('disabled', false);
            $theRow.find('.up-down-btn').prop('disabled', false);

            //set material run size
            $theRow.find('.current-mrs').val(matLength + 'x' + matWidth);
        }
    });
};

function AddPressToItem() {
    var $pressRow = $('#press_select_table').find('tr.selected');
    var theSel = $('#sp_' + $('#sp_adder_helper').val());
    var spAdderVal = $('#sp_adder_helper').val();

    if ($pressRow.length === 0) {
        $(theSel).val('');
        return;
    }

    var pressId = $pressRow.attr('data-press-id');
    $('#press_add_helper').val(pressId);
    var pressTitle = $pressRow.find('.press-title').text().trim();

    var $theChosenPressDetails = $('.quote-item-row[data-record-id="' + spAdderVal + '"] .chosen-press-details');
    $theChosenPressDetails.find('.press-name').html(pressTitle);

    $('.quote-item-row[data-record-id="' + spAdderVal + '"]').find('.press-name').html(pressTitle);
    $('.quote-item-row[data-record-id="' + spAdderVal + '"]').find('.selectedpress').val(pressId);

    $(theSel).val(pressId);

    $.ajax({
        type: 'POST',
        url: ProcessUrl('add-press-to-item'),
        data: {
            itemType: 'QUOTE',
            itemId: spAdderVal,
            pressId: pressId
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                let $row = $('.quote-item-row[data-record-id="' + spAdderVal + '"]');
                $row.find('.selectedpress').val(res);
                let speedId = $row.find('.selected-speed').val();

                //ajax request for default finishing and prepress services
                $.ajax({
                    type: 'GET',
                    url: ProcessUrl('Press/GetDefaultServices/') + pressId + '/' + spAdderVal + '/' + speedId + '/quote',
                    success: function (data) {
                        var d = JSON.parse(data);

                        for (let i = 0; i < d.prepress.length; i++) {
                            let qs = '#prepress_service_select_table input[type="checkbox"][data-record-type="service"][data-service-id="' + d.prepress[i].Service + '"]';
                            $(qs).prop('checked', true);
                        }
                        for (let i = 0; i < d.cutting.length; i++) {
                            let qs = '#cutting_service_select_table input[type="checkbox"][data-record-type="service"][data-service-id="' + d.cutting[i].Service + '"]';
                            $(qs).prop('checked', true);
                        }
                        for (let i = 0; i < d.finishing.length; i++) {
                            let qs = '#finishing_service_select_table input[type="checkbox"][data-record-type="service"][data-service-id="' + d.finishing[i].Service + '"]';
                            $(qs).prop('checked', true);
                        }

                        $('.builder-prepress-service-add').trigger('click');
                        $('.builder-cutting-service-add').trigger('click');
                        $('.builder-finishing-service-add').trigger('click');

                        $('#press_select_modal').modal('hide');

                        setTimeout(function () {
                            $('#press_add_helper').val('');
                        }, 1000);
                    }
                });
            } catch (e) { }
        }
    });
};

function CheckJobNumber() {
    $.get(ProcessUrl('check/' + $('#VM_Quote_Quote_JobNumber').val() + '/' + $('#VM_Quote_Quote_Id').val() + '/Quote'), function (data) {
        let isValid = (data === false);

        if (isValid) {
            //enable create button
            $('input[type="submit"]').prop('disabled', false);
            //add job-num-valid class to #Quote_JobNumber
            $('#VM_Quote_Quote_JobNumber').removeClass('job-num-invalid').addClass('job-num-valid');
        } else {
            //disable create button
            $('input[type="submit"]').prop('disabled', true);
            //add job-num-invalid class to #Quote_JobNumber
            $('#VM_Quote_Quote_JobNumber').removeClass('job-num-valid').addClass('job-num-invalid');
        }
    });
};

function ExpandCollapseList() {
    var theKey = $(this).attr('data-collapser-key');
    var $list = $('.collapser-child[data-collapser-key="' + theKey + '"]');

    //if any $list items have d-none, show the $list. Otherwise hide it
    //HOTFIX/HACK FROM ABOVE: check "resetting" var and handle appropriately
    //HOTFIX/HACK FROM ABOVE: check "configging" var and handle appropriately
    if ($list.hasClass('d-none') && !resetting) {
        if (configging) {
            let anyChecked = false;  // Flag to indicate if any checkbox is checked

            $list.each(function () {
                const checkbox = $(this).find('input[type="checkbox"]');

                if (checkbox.is(':checked')) {
                    anyChecked = true;
                    return false;  // Exit the loop if any checkbox is checked
                }
            });

            if (anyChecked) {
                $list.removeClass('d-none');
            }
        } else {
            $list.removeClass('d-none');
        }
    } else {
        $list.addClass('d-none');
    }
};

function SelectMaterialRow() {
    var $clicked = $(this);
    if ($clicked.hasClass('selected')) {
        $clicked.removeClass('selected');
    } else {
        $('#materials_select_table tbody tr.selected').removeClass('selected');
        $clicked.addClass('selected');
    }
};

function SelectPressRow() {
    var $clicked = $(this).parents('tr');
    if ($clicked.hasClass('selected')) {
        $clicked.removeClass('selected');
    } else {
        $('#press_select_table tbody tr.selected').removeClass('selected');
        $clicked.addClass('selected');
    }
};

function ResetCollapsers() {
    resetting = true;

    $('.collapser-parent').each(function () {
        $(this).trigger('click');
    });

    resetting = false;
};

function FrontColorInputHandler() {
    var $inp = $(this);
    var entry = $inp.val().toUpperCase();

    var $ctInp = $inp.parents('.chosen-press-colors-front').find('.press-color-count-front');
    var $nInp = $inp.parents('.chosen-press-colors-front').find('.press-color-notes-front');

    if (entry !== '4CP') {
        $ctInp.show();
        $nInp.show();
    } else {
        $ctInp.hide();
        $nInp.hide();
    }
};

function BackColorInputHandler() {
    var $inp = $(this);
    var entry = $inp.val().toUpperCase();

    var $ctInp = $inp.parents('.chosen-press-colors-back').find('.press-color-count-back');
    var $nInp = $inp.parents('.chosen-press-colors-back').find('.press-color-notes-back');

    if (entry !== 'NONE') {
        $ctInp.show();
        $nInp.show();
    } else {
        $ctInp.hide();
        $nInp.hide();
    }
};

function LoadClientContacts() {
    $('#contact_autocomplete').prop('disabled', false);
};

function ShowHideContacts() {
    if ($('.contact-list-row').is(':visible')) {
        $('.contact-list-row').hide();
        $('.show-hide-contacts').text('Show Contacts');
    } else {
        $('.contact-list-row').show();
        $('.show-hide-contacts').text('Hide Contacts');
    }
};

function ViewLayout() {
    let rId = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(rId);

    $.ajax({
        type: 'GET',
        url: ProcessUrl('Quote/ViewLayout') + '/' + rId,
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('#layout_modal .modal-body').html(res.html);
                $('#layout_modal').modal('show');
            } catch (e) {
            }
        }
    })
};

function SwapRunSizeValues() {
    var $ele = $(this); //element
    var rowOrdinal = $ele.attr('data-ordinal'); //ordinal
    var $qir = $ele.parents('.quote-item-row[data-item-ordinal="' + rowOrdinal + '"]'); //item row
    var $qir_rs_L = $qir.find('.material-run-size-l'); //mat run size l input
    var $qir_rs_W = $qir.find('.material-run-size-w'); //mat run size w input
    var curL = $qir_rs_L.val(); //mat l value
    var curW = $qir_rs_W.val(); //mat w value

    //setting W = L
    $qir_rs_W.val(curL);
    //setting L = W
    $qir_rs_L.val(curW);
};

function SpeedRadioHandler() {
    var $radio = $(this);
    var $p = $radio.parents('tr');

    var pSpeed = $p.attr('data-speed-val');
    var pSpeedUnit = $p.attr('data-speed-unit-val');

    $('.custom-speed-entry .override-speed-numerator').val(pSpeed);
    $('.custom-speed-entry #SpeedDenominator').val(pSpeedUnit);

    if ($p.hasClass('custom-speed')) {
        $('.custom-speed-entry').show();
    } else {
        $('.custom-speed-entry').hide();
    }
};

function UpdateItemSpeedInfo() {
    //if the $row of the selected radio has class "custom-speed" then get the value from the manual entry
    //otherwise do below
    var currentItemId = $('.current-item-id').val();
    var $p = $('#press_speed_select_table input[type="radio"]:checked').parents('tr');
    var pressSpeedId = $p.attr('data-record-id');
    var $row = $('.item-row[data-record-id="' + currentItemId + '"]');

    var pSpeed = $p.attr('data-speed-val');
    var pSpeedUnit = $p.attr('data-speed-unit-val');
    var pSpeedText = $p.attr('data-speed-unit-text');

    if ($p.hasClass('custom-speed')) {
        //get the custom speed
        pSpeed = $('#press_speed_select_modal .custom-speed-entry .override-speed-numerator').val();
        pSpeedUnit = $p.find('#press_speed_select_modal .custom-speed-entry #SpeedDenominator').val();
        pSpeedText = $p.find('#press_speed_select_modal .custom-speed-entry #SpeedDenominator option:selected').text();
    }

    $row.find('.selected-speed').val(pressSpeedId);

    $row.find('.selected-press-speed-display .speed').html(pSpeed);
    $row.find('.selected-press-speed-display .speed-unit').html(pSpeedText);
};

function GetServiceNotes() {
    var $n = $(this);
    $activeServiceItem = $n;
    var sId = $n.parents('li').attr('data-record-id');
    var isTemp = false;

    if (typeof sId === 'undefined') {
        sId = $n.parents('li').attr('data-service-id');
        isTemp = true;
        $n.parents('li').addClass('temp-notes');
    }

    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-item-notes/' + sId + '/quote/' + isTemp),
        success: function (data) {
            //load res into the modal for editing
            var res = JSON.parse(data);

            $('#service_note_modal .modal-body .service-notes').html(res.Notes);
            if (!isTemp) {
                $('#service_note_modal #s_notes_cur_id').val(res.Id);
            }
            if (isTemp) {
                tempNotes.push({ 'ServiceId': sId, 'RowOrdinal': $n.parents('.item-row').attr('data-item-ordinal'), 'Notes': '' });
            }
            $('#service_note_modal').modal('show');
        }
    });
};

function SaveServiceNotes() {
    var curSerId = $('#service_note_modal #s_notes_cur_id').val();
    var curSerNotes = $('#service_note_modal .service-notes').val();

    if ($activeServiceItem.parents('li').hasClass('temp-notes')) {
        //get the service id
        curSerId = $activeServiceItem.parents('li').attr('data-service-id');
        //get the ordinal
        var theOrdinal = $activeServiceItem.parents('.item-row').attr('data-item-ordinal');
        //get the notes
        var theNotes = curSerNotes;
        //console.log(theNotes);
        $activeServiceItem.parents('li').find('.ser-notes').html(theNotes);
        //update notes on the tempNotes array item that matches serviceId with curSerId and rowOrdinal with theOrdinal
        for (var i = 0; i < tempNotes.length; i++) {
            if (tempNotes[i].ServiceId === curSerId && tempNotes[i].RowOrdinal === theOrdinal) {
                tempNotes[i].Notes = theNotes;
            }
        }
    } else {
        $.ajax({
            type: 'POST',
            url: ProcessUrl('save-item-notes'),
            data: {
                id: curSerId,
                notes: curSerNotes,
                itemType: 'quote'
            },
            complete: function () {
                $activeServiceItem.parents('li').find('.ser-notes').html(theNotes);
            }
        });
    }
};

function LoadItemDocuments() {
    var $ele = $(this);
    var itemId = $ele.parents('.item-row').attr('data-record-id');
    var isOutsourced = $ele.parents('.item-row').hasClass('o-item-row');
    //set the field in the add document modal indicating if outsourced or not as a jic
    $('.ad-is-outsourced-item').val(isOutsourced);
    $('.delete-docs-btn').hide();

    $.ajax({
        type: 'GET',
        url: ProcessUrl('GetDocuments/quote/' + itemId + '/' + isOutsourced),
        beforeSend: function () {
            $('.document-list').html('');
        },
        success: function (data) {
            var res = JSON.parse(data);

            for (var i = 0; i < res.length; i++) {
                $('.document-list').append('<li data-doc-id="' + res[i].QuoteDocument.Id + '"><input type="checkbox" class="del-marker-cb" />' + res[i].DocumentName + '<i class="fa-regular fa-download"></i></li>');
            }

            $('.item-id').val(itemId);
        },
        complete: function () {
            $('#document_list_modal').modal('show');
        }
    });
};

function AddDocument() {
    //hide the document list modal and show the add document modal
    $('#document_list_modal').modal('hide');
    $('.item-type').val('quote');
    $('#add_document_modal').modal('show');
};

function AddDocCancel() {
    $('#document_list_modal').modal('show');
};

function ShowDeleteModal() {
    $('#document_list_modal').modal('hide');
    $('#delete_document_modal').modal('show');
};
function DeleteFromThisItem() {
};
function DeleteFromAllItems() {
};

function DownloadFile() {
    var $dlBtn = $(this);
    var id = $dlBtn.parent().attr('data-doc-id');

    window.open(ProcessUrl('get-document/' + id + '/quote'), "_blank");
};
function AdjustMaterialCost() {
    var $btn = $(this);
    var $row = $btn.parents('.item-row');
    $('#current_record_id').val($row.attr('data-record-id'));
    var curCost = $btn.parent().find('.material-cost-fmt').html().trim();
    $('#mat_price_override_modal .modal-body .current-material-price').html(curCost);
};

function SubmitMaterialPriceOverride() {
    var newPrice = $('#mat_price_override_modal .modal-body .new-material-price').val();
    var recordId = $('#mat_price_override_modal .modal-body #current_record_id').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('mat-price-override'),
        data: {
            id: recordId,
            newPrice: newPrice,
            recordType: 'Quote'
        },
        complete: function () {
            $('.quote-item-row[data-record-id="' + recordId + '"]').find('.material-cost-fmt').html('$' + newPrice);
        }
    });
};

function UpdateContact() {
    try {
        var contactId = $(this).parents('li').attr('data-record-id');
        $('#VM_Quote_Quote_Contact').val(contactId);
    } catch (e) { }
};

function SaveRecord() {
    justSaving = true;
    $('form#quote_builder').submit();
};

function CopyItem() {
    //CopyItem currently does NOT apply to outsourced items (just make another one manually)
    var $btn = $(this);
    var recordId = $btn.parents('.quote-item-row').attr('data-record-id');

    $.post(ProcessUrl('copy-item') + '/' + recordId + '/quote', function (data) {
        try {
            var res = JSON.parse(data);

            $('#job_items').append(res);
            NonTableRowRemoveAddHandler();
        } catch (e) { }
    });
};
function FocusCostField() {
    $('.new-material-price').focus();
};

function ViewQuoteTicket() {
    //Validator.js
    CheckFormValidation();

    if (failedValidation === false) {
        doingCalcs = true;

        //submit the form
        let formId = '#job_builder';
        let $theForm = $(formId);

        if (!$theForm.length) {
            $theForm = $('#quote_builder');
        }

        $theForm.submit();

        setTimeout(function () {
            window.location = ProcessUrl('GetQuoteTicket/' + $('#VM_Quote_Quote_Id').val());
        }, 2000);
    }
};

function SetHelperToRowId() {
    var rId = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(rId);
};

/*function SetHelperToRowId2() {
    var rID = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(rID);
};*/

/*function clearServiceList(serviceList) {
    $(serviceList).find('li').each(function () {
        var $t = $(this);
        if ($t.find('.item-is-required').length === 0) {
            $t.remove();
        }
    });

    let rowId = $(serviceList).parents('.item-row').attr('data-record-id');

    $.post(ProcessUrl('delete-services/quote/' + rowId));
};*/

function OverrideSheetCount() {
    $('#sp_adder_helper').val($(this).parents('.item-row').attr('data-record-id'));

    //open the modal
    $('#sheet_override_modal').modal('show');
};

function DoneEditingFinishingConfig() {
    var arr = [];
    //foreach tr in #finishing_material_config_table tbody
    $('#finishing_material_config_table tbody tr').each(function () {
        let $tr = $(this);
        let recordId = $tr.attr('data-record-id');
        let newConfigValue = $tr.find('.f-mat-config-val').val();
        let newAppValue = $tr.find('select').val();
        arr.push({ id: recordId, newValue: newConfigValue, newApplicationValue: newAppValue });
    });

    //get data-record-id from tr
    //get config value from .f-mat-config-val input inside of tr's td
    //POST an array of id/input values to /update-finishing-config along with the itemType
    $.ajax({
        type: 'POST',
        url: ProcessUrl('update-finishing-config'),
        data: {
            configs: arr,
            itemtype: 'quote'
        }
    });
};

function ClearMaterialConfigTableBody() {
    $('#finishing_material_config_table tbody tr').html('');
};

function RemoveServiceEntry() {
    let qisPrintServiceId = $(this).parents('li').attr('data-record-id'); // this is the quote item service id that needs to be deleted
    $.post(ProcessUrl('ajax-remove-service-entry') + '/' + qisPrintServiceId + '/quote');
};
function PickupShipToggle() {
    if ($('#rad_ship').is(':checked')) {
        //show shipping dropdown
        $('.ship-select-row').show();
    } else {
        //hide shipping dropdown
        $('.ship-select-row').hide();
    }
};

function UpdateShippingAddress() {
    let radio = $('#shipping_address_modal input:checked');
    let address = radio.parents('li').attr('data-record-id');
    //let selectedRadio = $('#shipping_address_modal input[type="radio"]:checked').parents('li').prop('data-record-id');
    let quoteId = $('#VM_Quote_Quote_Id').val();

    $('#VM_Quote_Quote_ShippingAddress').val(address);

    $.ajax({
        type: 'POST',
        url: ProcessUrl('shipping-address-change'),
        data: {
            itemtype: 'quote',
            addressId: address,
            recordId: quoteId
        }
    });
};
function LoadShippingAddresses() {
    var clientId = $('#VM_Quote_Quote_Client').val();
    var quoteId = $('#VM_Quote_Quote_Id').val();

    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-shipping-addresses') + '/' + clientId + '/' + quoteId + '/quote',
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('#shipping_address_list').html(res);
            } catch (e) { }
        }
    })
};

function LinkItem() {
    var $btn = $(this);
    var $itemToLink = $btn.parents('.item-row');
    //find the closest .item-row above which does not have the .sub-item class
    var $linkItem = $itemToLink.closest('.item-row').prevAll('.item-row').not('.sub-item,.o-item').first();

    if ($linkItem.length > 0) {
        //link to this item
        $itemToLink.addClass('sub-item');

        let srcItemId = $itemToLink.attr('data-record-id');
        let destItemId = $linkItem.attr('data-record-id');
        let iType = 'quote';

        //set the hidden field
        $itemToLink.find('.subitem-of').val(destItemId);

        let isOutsource = $itemToLink.hasClass('o-item-row');

        if (isOutsource) {
            iType = 'o-quote';
        }

        $.ajax({
            type: 'POST',
            url: ProcessUrl('subitem-link'),
            data: {
                srcItem: srcItemId,
                destItem: destItemId,
                itemtype: iType
            },
            success: function () {
                let $unlinkBtn = $btn.parents('.item-row').find('.unlink-item-btn');
                $unlinkBtn.show();
                $btn.hide();
            }
        });
    }
};

function UnlinkItem() {
    let $btn = $(this);
    let $itemToUnlink = $btn.parents('.item-row');
    let itemId = $itemToUnlink.attr('data-record-id');
    let iType = 'quote';

    $itemToUnlink.find('.subitem-of').val('');

    let isOutsource = $itemToUnlink.hasClass('o-item-row');

    if (isOutsource) {
        iType = 'o-quote';
    }

    $.ajax({
        type: 'POST',
        url: ProcessUrl('subitem-unlink'),
        data: {
            idToUnlink: itemId,
            itemtype: iType
        },
        success: function () {
            let $linkBtn = $btn.parents('.item-row').find('.link-item-btn');
            $linkBtn.show();
            $btn.hide();
            $itemToUnlink.removeClass('sub-item');
        }
    });
};

function GenerateCustomerQuote() {
    let recordId = $('#VM_Quote_Quote_Id').val();
    window.open(ProcessUrl('generate-customer-quote3') + '/' + recordId, "_blank");
};

function DuplicateQuote() {
    let quoteId = $('#VM_Quote_Quote_Id').val();
    $.ajax({
        type: 'POST',
        url: ProcessUrl('quote/duplicate'),
        data: {
            id: quoteId
        },
        success: function (data) {
            //console.log(data);
            //data will be the id of the new quote
            window.location = ProcessUrl('quote/edit/' + data);
        }
    });
};

function CustomVendorAdditionSerialization(evt) {
    evt.preventDefault();

    var form = $('#vendor_adder').serializeArray();
    let formParsed = {};
    $.each(form, function (index, field) {
        formParsed[field.name] = field.value;
    });
    $.ajax({
        type: 'POST',
        url: ProcessUrl('vendor/dynamic-create'),
        data: {
            vendor: formParsed
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);

                let newSelectHtml = '';
                for (var i = 0; i < res.length; i++) {
                    newSelectHtml = (newSelectHtml + '<option value="' + res[i].Value + '">' + res[i].Text + '</option>');
                }

                //update all selects on outsourced items and ensure the current value is reselected
                $('select[name="QuoteOutsourcedItem.Vendor"]').each(function () {
                    let $sel = $(this);
                    let curVal = $(this);
                    $sel.html(newSelectHtml);
                    $sel.val(curVal);
                });
            } catch (e) { }
        }
    });
};

function CustomMaterialAdditionSerialization(evt) {
    evt.preventDefault();

    var form = $('#material_adder').serializeArray();
    let formParsed = {};
    $.each(form, function (index, field) {
        formParsed[field.name] = field.value;
    });
    $.ajax({
        type: 'POST',
        url: ProcessUrl('material/dynamic-create'),
        data: {
            material: formParsed
        },
        success: function (data) {
            try {
                $('#materials_select_modal').remove();
                GetMaterialModel();
            } catch (e) { }
        }
    });
};

function GetMaterialModel() {
    $.get(ProcessUrl('get-material-model'), function (data) {
        try {
            let res = JSON.parse(data);

            if ($('.create-wrapper')) {
                $('.create-wrapper').append(res);
            }
            if ($('.edit-wrapper').length) {
                $('.edit-wrapper').append(res);
            }
        } catch (e) { }
    });
};

function GetPressModel() {
    $.get(ProcessUrl('get-press-model'), function (data) {
        try {
            let res = JSON.parse(data);

            if ($('.create-wrapper')) {
                $('.create-wrapper').append(res);
            }
            if ($('.edit-wrapper').length) {
                $('.edit-wrapper').append(res);
            }
        } catch (e) { }

        pst = $('#press_select_table').DataTable({
            'paging': false
        });
    });
};

function SetBlindShipping(bs) {
    $('#VM_Quote_Quote_BlindShipping_Value').prop('checked', bs);
};

function LoadService() {
    var serRecId = $(this).parents('li').attr('data-record-id');

    $.ajax({
        type: 'GET',
        url: ProcessUrl('QuoteItemService/Edit/' + serRecId),
        complete: function (data) {
            //data should be the html for the service edit, so load it
            var $loadDest = $('#edit_service_modal .modal-body');
            $loadDest.html(JSON.parse(data.responseJSON));

            //then click the button
            var btnId = '#editservice';

            $(btnId).trigger('click');
        }
    });
};

function SaveServiceConfiguration(e) {
    e.preventDefault();

    var form = $('#qis_configure_form').serialize();
    var formData = decodeURIComponent(form); // Decode the URI component
    var formDataObject = {};

    formData.split('&').forEach(function (item) {
        var parts = item.split('=');
        var key = parts[0].replace('QuoteItemService.', '').replace('ServiceTimeEditor.', '');
        formDataObject[key] = parts[1];
    });

    //delete the LockTime property
    delete formDataObject.LockTime;

    //set UserTimeOverride to LockTime
    formDataObject.UserTimeOverride = $('#qis_configure_form #ServiceTimeEditor_LockTime').is(':checked');

    $.ajax({
        type: 'POST',
        url: ProcessUrl('quote-service-item/save'),
        data: {
            quoteItemService: formDataObject
        },
        complete: function () {
            $('.service-list li[data-record-id="' + formDataObject.Id + '"] .item-notes').html(formDataObject.Notes);
        }
    });
};

function LoadCuttingServices() {
    //load the list of cutting services and nest their possible configurations beneath them
    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-cutting-services'),
        success: function (data) {
            var res = JSON.parse(data);
            //data will contain the html
            //load into the modal body
            $('#cutting_service_modal .modal-body').html(res);
        }
    });
};

function MarkCuttingService() {
    var $t = $(this);

    $t.hasClass('selected') ?
        $t.removeClass('selected') :
        $t.addClass('selected');

    if (!$t.hasClass('selected')) {
        $t.parents('li').find('.config-list .service-config-option.selected').removeClass('selected');
    }
};

function MarkCuttingConfiguration() {
    var $t = $(this);

    $t.parents('.config-list').find('.selected').removeClass('selected');
    $t.parents('li:not(.service-config-option)').find('.service-title').addClass('selected');

    $t.hasClass('selected') ? $t.removeClass('selected') : $t.addClass('selected');
};

function AddCuttingServices() {
    var services = [];

    //delete any cutting services currently on the item
    $('.item-row[data-record-id="' + $('#sp_adder_helper').val() + '"] .is-cutting-service[value="True"]').each(function (index, item) {
        $(item).parent().find('.remove-link-li').trigger('click');
    });

    // Iterate through each selected service title
    $('.service-title.selected').each(function () {
        var serviceId = $(this).data('record-id');

        // Retrieve the first selected configuration option
        var configOption = $(this).closest('li').find('.service-config-option.selected').first();
        var configId = configOption.data('record-id');
        var configText = configOption.text().trim();

        // Add the service and its configuration option to the services array
        services.push({
            serviceId: serviceId,
            configId: configId,
            configText: configText
        });
    });

    let rowId = $('#sp_adder_helper').val();
    let recordType = 'QUOTE';

    $.ajax({
        type: 'POST',
        url: ProcessUrl('add-cutting-services'),
        data: {
            services,
            rowId,
            recordType
        },
        success: function (data) {
            //data should contain new service rows
            try {
                let res = JSON.parse(data);
                let curHtml = $('.item-row[data-record-id="' + rowId + '"] .service-list').html();

                $('.item-row[data-record-id="' + rowId + '"] .service-list').html(curHtml + res.services);
            } catch (e) { }
        },
        complete: function (data) {
            $('.save-record').trigger('click');
            $('.run-calcs').trigger('click');
        }
    });
};

function ChangeCuttingConfig() {
    let recordId = $(this).attr('data-record-id');
    $('#sp_adder_helper').val(recordId);
    $('#cutting_service_modal .current-cutting-service-item-id').val(recordId);
    $('#cutting_service_modal').modal('show');
};

function ConvertToJob() {
    //get quoteid
    let qid = $('#VM_Quote_Quote_Id').val();
    $.ajax({
        type: 'POST',
        url: ProcessUrl('Job/CreateJobFromQuote'),
        data: {
            quoteId: qid
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);
                window.location = ProcessUrl('Job/Edit/' + res);
            } catch (e) { }
        }
    });
};

function SaveThenCalculate() {
    doingCalcs = true;
    $('form#quote_builder').submit();
};

function OpenFinishingMaterials() {
    //select checkboxes for the currently selected materials
    let rowId = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(rowId);
    $('#finishing_selected_mats').html('');
    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-selected-finishing-materials/quote/' + rowId),
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('#finishing_material_select_table tbody input[type="checkbox"]:checked').prop('checked', false);
                for (let i = 0; i < res.length; i++) {
                    $('#finishing_material_select_table tbody input[type="checkbox"][data-material-id="' + res[i].Material + '"]').prop('checked', true);
                    $('#finishing_selected_mats').append(`<div>${res[i].Title} <i>(${res[i].Category})</i></div>`);
                }

                $('#finishing_material_select_modal .sidebar-container li:first-child').trigger('click');
            } catch (e) { }
        }
    });
};

function SaveFinishingMaterialConfigs() {
    //update-finishing-config (POST)
    //configs (List<FinishingConfig_CM>)
    //itemId (int?)
    //itemtype (string)
    let itemId = $('#sp_adder_helper').val();
    let configs = [];

    $('#finishing_material_config_table tbody tr').each(function () {
        let $row = $(this);
        configs.push({
            id: $row.attr('data-record-id'),
            value: $row.find('.ffc-input-val').val(),
            applicationValue: $row.find('select[name="ffaSel"]').val(),
            cost: $row.find('.cost-input-val').val()
        });
    });

    $.ajax({
        type: 'POST',
        url: ProcessUrl('update-finishing-config'),
        data: {
            itemtype: 'quote',
            configs
        }
    });
};

function LoadFinishingMaterialConfigs() {
    //render the configs
    let rowId = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(rowId);

    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-finishing-material-configs') + '/quote/' + rowId,
        beforeSend: function () {
            $('#finishing_material_config_modal table tbody').html('');
        },
        success: function (data) {
            try {
                let res = JSON.parse(data);

                for (let i = 0; i < res.length; i++) {
                    let newHtmlJson = JSON.parse(res[i].FinishingFormulaConfiguration);
                    let sel = $('.base-ffa-sl').clone();
                    let propertyKey = '';
                    let propertyValue = '';

                    // Loop through the object properties; currently only has one key/value pair
                    for (const key in newHtmlJson) {
                        if (newHtmlJson.hasOwnProperty(key)) {
                            propertyKey = key;
                            propertyValue = newHtmlJson[key];
                        }
                    }

                    // Build the new HTML row
                    let newHtml = `
                                    <tr data-record-id="${res[i].Id}">
                                        <td>${res[i].Title}</td>
                                        <td>${propertyKey}<input type="text" class="ffc-input-val" value="${propertyValue}" />
                                            <select name="ffaSel">
                                                <option value="" selected></option>
                                                ${sel.html()}
                                            </select>
                                        </td>
                                        <td><input type="text" class="cost-input-val" value="${res[i].Cost}" /></td>
                                        <td>${res[i].CostType}</td>
                                    </tr>
                                `;

                    // Append the new row to the table body
                    $('#finishing_material_config_modal table tbody').append(newHtml);

                    // After appending, find the last inserted select element in the table body
                    let $newSelect = $('#finishing_material_config_modal table tbody tr:last-child select[name="ffaSel"]');

                    // Find the option that matches the CostTypeId and mark it as selected
                    $newSelect.find(`option[value="${res[i].FinishingFormulaApplication}"]`).prop('selected', true);
                }
                //render configs into config list
            } catch (e) { }
        }
    });
};

function UpdateFinishingMaterials() {
    //update-finishing-materials (POST)
    //itemId (int?)
    let itemId = $('#sp_adder_helper').val();
    //matIds (List<int>)
    let fmIds = [];
    $('#finishing_material_select_modal input[type="checkbox"][data-material-id][data-config-label][data-config-value]:checked').each(function () {
        fmIds.push($(this).attr('data-material-id'));
    });
    //itemtype (string)
    let itemtype = 'quote';

    $.ajax({
        type: 'POST',
        url: ProcessUrl('update-finishing-materials'),
        data: {
            itemId,
            fmIds,
            itemtype
        }
    });
};

function OpenServiceSettings() {
    let $li = $(this);
    $li.find('.fa-gears').trigger('click');
};

function GetShippingAddressModel() {
    let $form = $('#shipping_address_adder');
    let sa = {};
    sa.CustomerName = $form.find('input[name="CustomerName"]').val();
    sa.Address = $form.find('input[name="Address"]').val();
    sa.Address2 = $form.find('input[name="Address2"]').val();
    sa.City = $form.find('input[name="City"]').val();
    sa.State = $form.find('select[name="State"]').val();
    sa.Zip = $form.find('input[name="Zip"]').val();
    sa.Phone = $form.find('input[name="Phone"]').val();
    sa.Attention = $form.find('input[name="Attention"]').val();
    sa.Client = $('#VM_Quote_Quote_Client').val();

    return sa;
};

function CustomShippingAddressSerialization(evt) {
    evt.preventDefault();

    var form = GetShippingAddressModel();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('dynamic-shipping-address'),
        data: {
            address: form
        }
    });
};

function ReRenderRowServices(rowId) {
    let $row = $('.quote-item-row[data-record-id="' + rowId + '"]');
    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-service-list/quote/' + rowId),
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $row.find('.prepress-service-list').html('');
                $row.find('.cutting-service-list').html('');
                $row.find('.finishing-service-list').html('');
                $row.find('.prepress-service-list').html(res.prepressServices);
                $row.find('.cutting-service-list').html(res.cuttingServices);
                $row.find('.finishing-service-list').html(res.finishingServices);
            } catch (e) { }
        }
    });
};

function ClearShippingAddress() {
    let recordId = $('#VM_Quote_Quote_Id').val();
    let itemtype = 'quote';

    $.ajax({
        type: 'POST',
        url: ProcessUrl('clear-shipping-address'),
        data: {
            recordId,
            itemtype
        }
    });
};

function OpenPressSpeedSettings() {
    //get the press id
    let pressId = $(this).attr('data-press-id');
    //load the speeds for the press
    //set the selected speed

    $.ajax({
        type: 'GET',
        url: ProcessUrl('item-load-speeds/' + pressId),
        success: function (data) {
            $('#press_speed_select_modal tbody').html(data);
        },
        complete: function () {
            //find the selected radio button in #press_speed_select_modal tbody and click it
            var $selected = $('#press_speed_select_modal tbody input[type="radio"]:checked');
            if ($selected.length > 0) {
                $selected.trigger('click');
            }

            $('#press_select_modal').modal('hide');
            $('#press_speed_select_modal').modal('show');
        }
    });
};

function CloseSpeedSettingsAndOpenPressSelect() {
    $('#press_speed_select_modal').modal('hide');
    $('#press_select_modal').modal('show');
};

function UpdateSelectedPressSpeed() {
    //update the record
    let speedId = $('#press_speed_select_table input:checked').parents('tr').attr('data-record-id');
    let speedUnitVal = $('#press_speed_select_table input:checked').parents('tr').attr('data-speed-unit-val');
    let speedUnitText = $('#press_speed_select_table input:checked').parents('tr').attr('data-speed-unit-text');
    let speedValue = $('#press_speed_select_table input:checked').parents('tr').attr('data-speed-val');

    $('#print_speed_ref_sl').val(speedUnitVal);
    //update the press table display
    let itemId = $('#sp_adder_helper').val();
    //selected press -> press speed text -> new value
    let $item = $('.quote-item-row[data-record-id="' + itemId + '"]');
    $item.find('.selected-press-speed-display .speed').html(speedValue);
    $item.find('.selected-press-speed-display .speed-unit').html(speedUnitText);
    $item.find('.selected-speed').val(speedId);
};

function SubmitMaterialConfig() {
    let rowId = $('#sp_adder_helper').val();
    let itemType = 'quote';
    let $modal = $('#material_config_modal');

    let mConfig = {
        ColorFrontProfile: $modal.find('.press-color-string-front').val(),
        ColorBackProfile: $modal.find('.press-color-string-back').val(),
        ColorFrontCount: $modal.find('.press-color-count-front-inp').val(),
        ColorBackCount: $modal.find('.press-color-count-back-inp').val(),
        ColorFrontNotes: $modal.find('.press-color-notes-front-inp').val(),
        ColorBackNotes: $modal.find('.press-color-notes-back-inp').val(),
        RunLength: $modal.find('.material-run-size-l').val(),
        RunWidth: $modal.find('.material-run-size-w').val(),
        Sheets: $modal.find('.sheets').val(),
        ScrapSheets: $modal.find('.scrap-sheets').val(),
        RunSheets: $modal.find('.run-sheets').val(),
        Up: $modal.find('.up-value').val(),
        DoubleInk: $modal.find('.double-ink-checkbox').is(':checked'),
        Collate: $modal.find('.collate-checkbox').is(':checked'),
        Staple: $modal.find('.staple-checkbox').is(':checked'),
        MaterialCost: $modal.find('.material-cpu').val()
    };

    //also update $row.find('.current-mrs') with the new value (i.e. 20x50) so that the value is reinforced when the record is saved (or on calc which saves)
    let $row = $('.quote-item-row[data-record-id="' + rowId + '"]');
    $row.find('.current-mrs').val(mConfig.RunLength + 'x' + mConfig.RunWidth);

    $.ajax({
        type: 'POST',
        url: ProcessUrl('update-material-config'),
        data: {
            config: mConfig,
            itemId: rowId,
            itemType
        },
        complete: function () {
            $row.find('.stock-row .back-color-display')
            $row.find('.stock-row .run-size').html(mConfig.RunLength + 'x' + mConfig.RunWidth);
            $row.find('.stock-row .sheets-display').html(mConfig.Sheets);
            $row.find('.stock-row .out-display').html('1');
            $row.find('.stock-row .calced-up-val').html(mConfig.Up);
            console.log($row.find('.stock-row .front-color-display').html(mConfig.ColorFrontProfile + '  ' + mConfig.ColorFrontNotes));
            console.log($row.find('.stock-row .back-color-display').html(mConfig.ColorBackProfile + '  ' + mConfig.ColorBackNotes));
        }
    });
};

function LoadMaterialConfig() {
    let itemId = $(this).parents('.quote-item-row').attr('data-record-id');
    $('#sp_adder_helper').val(itemId);

    $.ajax({
        type: 'GET',
        url: ProcessUrl('get-material-config') + '/' + itemId + '/quote',
        success: function (data) {
            try {
                let res = JSON.parse(data);
                let $modal = $('#material_config_modal');
                $modal.find('.press-color-string-front').val(res.ColorFrontProfile);
                $modal.find('.press-color-string-back').val(res.ColorBackProfile);
                $modal.find('.press-color-count-front-inp').val(res.ColorFrontCount);
                $modal.find('.press-color-count-back-inp').val(res.ColorBackCount);
                $modal.find('.press-color-notes-back-inp').val(res.ColorBackNotes);
                $modal.find('.press-color-notes-front-inp').val(res.ColorFrontNotes);
                $modal.find('.material-run-size-l').val(res.RunLength);
                $modal.find('.material-run-size-w').val(res.RunWidth);
                $modal.find('.sheets').val(res.Sheets);
                $modal.find('.scrap-sheets').val(res.ScrapSheets);
                $modal.find('.run-sheets').val(res.RunSheets);
                $modal.find('.up-value').val(res.Up);
                $modal.find('.mct-display').html(res.MaterialCostType);
                $modal.find('.material-cpu').val(res.MaterialCost);

                if (res.UserSheetOverride) {
                    $modal.find('.clear-sheet-override').show();
                } else {
                    $modal.find('.clear-sheet-override').hide();
                }

                $modal.modal('show');
            } catch (e) {
            }
        }
    });
};

function IncrementUpValue() {
    let $row = $(this).parents('.quote-item-row');
    let rId = $row.attr('data-record-id');
    let curUp = Number($row.find('.calced-up-val').html().trim());
    $row.find('.calced-up-val').html(curUp + 1);
};

function DecrementUpValue() {
    let $row = $(this).parents('.quote-item-row');
    let rId = $row.attr('data-record-id');
    let curUp = Number($row.find('.calced-up-val').html().trim());
    $row.find('.calced-up-val').html(curUp - 1);
};

function UpdateFinishSizeDisplay() {
    let $row = $(this).parents('.quote-item-row');
    let w = $row.find('input.item-width').val();
    let l = $row.find('input.item-length').val();
    let fsd = l + ' x ' + w;

    $row.find('.finish-size-display').html(fsd);
};

function ArtworkProvidedToggle() {
    let $cb = $(this);
    let checked = $cb.is(':checked');
    let $parent = $cb.parents('.item-right-ticket-wrapper');

    if (!checked) {
        console.log('hiding time input');
        $parent.find('.design-time-input').addClass('d-none');
        $parent.find('.design-time-input input').val(0);
    } else {
        console.log('showing time input');
        $parent.find('.design-time-input').removeClass('d-none');
    }
};

function DoubleInkHelper() {
    let c = $(this).is(':checked');
    let rowId = $('#sp_adder_helper').val();
    let $row = $('.quote-item-row[data-record-id="' + rowId + '"]');

    $row.find('.press-double-ink').prop('checked', c);
};

function CollateHelper() {
    let c = $(this).is(':checked');

    let rowId = $('#sp_adder_helper').val();
    let $row = $('.quote-item-row[data-record-id="' + rowId + '"]');

    $row.find('.press-double-ink').prop('checked', c);
};

function StapleHelper() {
    let c = $(this).is(':checked');

    let rowId = $('#sp_adder_helper').val();
    let $row = $('.quote-item-row[data-record-id="' + rowId + '"]');

    $row.find('.press-double-ink').prop('checked', c);
};

function FilterFinishingMaterials() {
    let catName = $(this).html().trim();
    $('tr.fin-material-row').hide();
    $('tr.fin-material-row[data-cat-name="' + catName + '"]').show();
};

function ClearSheetOverride() {
    let rId = $('#sp_adder_helper').val();

    $.ajax({
        type: 'POST',
        url: ProcessUrl('clear-sheet-override'),
        data: {
            itemtype: 'quote',
            itemId: rId
        },
        success: function () {
            $('#material_select_modal .clear-sheet-override').hide();
        }
    });
};

function setHeaderWidth() {
    let sidenavWidth = $('.sidenav').width();
    let windowWidth = $(window).width();
    console.log('setHeaderWidth() = ' + (windowWidth - sidenavWidth));
    $('.edit-quote-wrapper').width(windowWidth - sidenavWidth);
};

$(function () {
    GetMaterialModel();
    GetPressModel();
    //GetFinishingMaterialsModel();

    $('#client_autocomplete').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: ProcessUrl("AutocompleteClient"),
                type: 'GET',
                data: {
                    'q': request.term
                },
                beforeSend: function () {
                    $('.contact-list-wrapper').hide();
                },
                success: function (data) {
                    let d = JSON.parse(data);
                    response($.map(d, function (item) {
                        return {
                            label: item.Title,
                            value: item.Title,
                            recordId: item.Id,
                            contactArr: item.Contacts,
                            markup: item.Markup,
                            defaultAddressId: item.DefaultAddress
                        }
                    }));
                }
            });
        },
        select: function (event, ui) {
            $('#VM_Quote_Quote_Client').val(ui.item.recordId);
            //load the contacts
            LoadClientContacts();
            $('div.special-markup-btn').html((ui.item.markup * 100) + '%');
            $('#VM_Quote_Quote_MarkupOverride').val(ui.item.markup);
        }
    });

    $('#contact_autocomplete').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: ProcessUrl("AutocompleteContact"),
                type: 'GET',
                data: {
                    'q': request.term,
                    'clientId': $('#VM_Quote_Quote_Client').val()
                },
                success: function (data) {
                    try {
                        let d = JSON.parse(data);
                        response($.map(d, function (item) {
                            return { label: (item.FirstName + " " + item.LastName), value: (item.FirstName + " " + item.LastName), recordId: item.Id }
                        }));
                    } catch (e) { }
                }
            });
        },
        select: function (event, ui) {
            $('#VM_Quote_Quote_Contact').val(ui.item.recordId);
            //render the contact information here
        }
    });

    $('#add_document_modal form').submit(function (e) {
        e.preventDefault();

        var formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false
        });
    });

    // Attach event listeners to all clear buttons
    /*document.querySelectorAll('.clear-all-services').forEach(button => {
        button.addEventListener('click', function () {
            // Find the closest parent that contains both the button and the list
            let parentContainer = $(this).parent().find('.ui-sortable'); // Adjust the selector as per your HTML structure
            clearServiceList(parentContainer);
        });
    });*/

    if ($('#VM_Quote_Quote_Client').val() !== '') {
        $('#contact_autocomplete').prop('disabled', false);
    }

    $('.service-list').each(function () {
        let $list = $(this);
        $list.sortable();
    });

    //set sub-navbar width (window width - sidenav width)
    let sidenavWidth = $('.sidenav').width();
    let windowWidth = $(window).width();
    $('.edit-quote-wrapper').width(windowWidth - sidenavWidth);

    setHeaderWidth();

    $(window).on('resize', setHeaderWidth);

    $('input,select,textarea').on('focus', ChangeDetector);
    $('input,select,textarea').on('blur', ChangeDetectorCheck);
})
    .on('click', '#materials_select input[type="checkbox"]', AddButtonHandler)
    .on('click', '.select-material-button', SelectMaterials)
    .on('click', '.select-press-btn', SelectPresses)
    .on('click', '.add-item-btn', AddItem)
    .on('click', '#job_items .remove-btn', RemoveItem)
    .on('submit', '#quote_builder:not(#qis_configure_form)', CustomFormSerialization)
    .on('click', '.builder-product-add', AddMaterialToItem)
    .on('click', '.builder-press-add', AddPressToItem)
    .on('blur', '#VM_Quote_Quote_JobNumber', CheckJobNumber)
    .on('click', '.collapser-parent', ExpandCollapseList)
    .on('click', '.builder-prepress-service-add', AddPrepressServicesToItem)
    .on('click', '.builder-cutting-service-add', AddCuttingServicesToItem)
    .on('click', '.builder-finishing-service-add', AddFinishingServicesToItem)
    .on('click', '#materials_select_table tbody tr', SelectMaterialRow)
    .on('click', '#press_select_table tbody tr .press-title,#press_select_table tbody tr .speed-settings-text', SelectPressRow)
    .on('click', '.show-hide-contacts', ShowHideContacts)
    .on('click', '.view-layout-btn', ViewLayout)
    .on('click', '.swap-icon-wrapper', SwapRunSizeValues)
    .on('click', '#press_speed_select_table input[type="radio"]', SpeedRadioHandler)
    .on('click', '.update-press-speed', UpdateItemSpeedInfo)
    .on('click', '.selected-items-row .fa-note', GetServiceNotes)
    .on('click', '.save-service-notes', SaveServiceNotes)
    .on('click', '#materials_select_modal .sidebar-container li', LoadMaterials)
    .on('click', '.doc-link', LoadItemDocuments)
    .on('click', '.add-doc-btn', AddDocument)
    .on('click', '.cancel-add-doc', AddDocCancel)
    .on('click', '.this-item', DeleteFromThisItem)
    .on('click', '.all-items', DeleteFromAllItems)
    .on('click', '.document-list .fa-download', DownloadFile)
    .on('click', '.adjust-mat-cost-btn', AdjustMaterialCost)
    .on('click', '.submit-mat-price-override-btn', SubmitMaterialPriceOverride)
    .on('click', '.contact-list input[type="radio"]', UpdateContact)
    .on('click', '.save-record', SaveRecord)
    .on('click', '.dup-item-btn', CopyItem)
    .on('shown.bs.modal', '#mat_price_override_modal', FocusCostField)
    .on('click', '.add-outsourced-item-btn', AddOutsourcedItem)
    .on('click', '.view-quote-ticket-btn', ViewQuoteTicket)
    .on('click', '.select-finishing-materials-btn', SetHelperToRowId)
    .on('click', '.override-sheet-amount', OverrideSheetCount)
    .on('click', 'ul .remove-link-li', RemoveServiceEntry)
    .on('click', 'input[name="pickup_ship"]', PickupShipToggle)
    .on('click', '.update-shipping-address-btn', UpdateShippingAddress)
    .on('show.bs.modal', '#shipping_address_modal', LoadShippingAddresses)
    .on('click', '.link-item-btn', LinkItem)
    .on('click', '.unlink-item-btn', UnlinkItem)
    .on('click', '.duplicate-quote-btn', DuplicateQuote)
    .on('click', '.save-dynamic-vendor', CustomVendorAdditionSerialization)
    .on('click', '.save-dynamic-material', CustomMaterialAdditionSerialization)
    .on('click', '.view-customer-quote-btn', GenerateCustomerQuote)
    .on('click', '.quote-item-row .service-list .fa-gears', LoadService)
    .on('submit', '#qis_configure_form', SaveServiceConfiguration)
    .on('blur', 'input[name="ServiceTimeEditor.FormattedServiceTime"]', ConvertFormattedToDecimal)
    .on('blur', 'input[name="ServiceTimeEditor.ServiceTime"]', ConvertServiceTimeToFormatted)
    .on('show.bs.modal', '#cutting_service_modal', LoadCuttingServices)
    .on('click', '.cutting-service-list .service-title', MarkCuttingService)
    .on('click', '.cutting-service-list .service-config-option', MarkCuttingConfiguration)
    .on('click', '.add-cutting-services', AddCuttingServices)
    .on('click', '.change-cutting-config', ChangeCuttingConfig)
    .on('click', '.convert-to-job-btn', ConvertToJob)
    .on('click', '.run-calcs', SaveThenCalculate)
    .on('click', '.finishing-materials-config-btn', LoadFinishingMaterialConfigs)
    .on('click', '.finishing-material-config-done', SaveFinishingMaterialConfigs)
    .on('click', '.finishing-materials-btn', OpenFinishingMaterials)
    .on('click', '.builder-finishing-materials-add', UpdateFinishingMaterials)
    .on('dblclick', '.service-list li', OpenServiceSettings)
    .on('submit', '#shipping_address_adder', CustomShippingAddressSerialization)
    .on('click', '.clear-address-btn', ClearShippingAddress)
    .on('click', '.pre-ser-add-btn,.cut-ser-add-btn,.fin-ser-add-btn', SetHelperToRowId)
    .on('click', '.press-speed-settings .open-settings', OpenPressSpeedSettings)
    .on('click', '#press_speed_select_modal button', CloseSpeedSettingsAndOpenPressSelect)
    .on('click', '#press_speed_select_modal .update-press-speed', UpdateSelectedPressSpeed)
    .on('click', '.material-config-finish', SubmitMaterialConfig)
    .on('click', '.open-material-config', LoadMaterialConfig)
    .on('click', '.up-up-btn', IncrementUpValue)
    .on('click', '.up-down-btn', DecrementUpValue)
    .on('blur', 'input.item-length,input.item-width', UpdateFinishSizeDisplay)
    .on('click', '.artwork-provided', ArtworkProvidedToggle)
    .on('click', '#material_config_modal .double-ink-checkbox', DoubleInkHelper)
    .on('click', '#material_config_modal .collate-checkbox', CollateHelper)
    .on('click', '#material_config_modal .staple-checkbox', StapleHelper)
    .on('click', '#finishing_material_select_modal .modal-body .sidebar-container li', FilterFinishingMaterials)
    .on('click', '.clear-sheet-override', ClearSheetOverride);
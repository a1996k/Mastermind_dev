﻿var printTable;

function JobItemSelect(e) {
    var $j = $(this);
    let rId = $j.attr('data-record-id');
    $('.job-context-menu #qa_selected_job_id').val(rId);
    //toggle the clicked job class on the clicked element
    $j.toggleClass('clicked-job');
    //remove clicked-job from .job-item elements that are not $j
    $('.job-item').not($j).removeClass('clicked-job');
    //if .toast-overlay has auto-slide-hidden and the amount of .clicked-job elements is not zero, click the toast-overlay
    //if .toast-overlay has auto-slide-shown and the amount of .clicked-job elements is zero, click the toast-overlay
    if (
        ($('.toast-overlay').hasClass('auto-slide-hidden') && $('.clicked-job').length > 0) ||
        ($('.toast-overlay').hasClass('auto-slide-shown') && $('.clicked-job').length == 0)
    ) {
        $('.toast-overlay').trigger('click');
    }
};

function EmptyJobListHandler() {
    $('ul.empty-list').removeClass('empty-list');
    $('ul:not(:has(li))').addClass('empty-list');
};

function ToggleQuickEditButtonDisplay() {
    $('.quick-edit-buttons').toggleClass('d-none');
};

function DestroyJobTable() {
    printTable.DataTable().destroy(false);
};

$(function () {
    //InstantiateJobTable();

    EmptyJobListHandler();
})
    .on('click', '.job-item', JobItemSelect);
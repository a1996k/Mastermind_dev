﻿let rangeStart = '';
let rangeEnd = '';

let
    agencyOverviewChart,
    quoteMetricsChart,
    jobCompletionMetricsChart,
    orgCostChart,
    topClientsChart,
    marginChart;

let iAgencyOverviewTable,
    aCompletedJobSummaryTable,
    aTopClientsTable,
    aUtilizationTable;

function calculateAverage(data) {
    const total = data.reduce((sum, point) => sum + parseFloat(point.y), 0);
    return total / data.length;
}

// Plugin to draw the average line
const averageLinePlugin = {
    id: 'averageLine',
    afterDatasetsDraw: (chart) => {
        const { ctx, chartArea: { top, right, bottom, left, width, height } } = chart;
        const yScale = chart.scales['y'];

        chart.data.datasets.forEach((dataset, index) => {
            const data = dataset.data;
            const average = calculateAverage(data);
            const yPos = yScale.getPixelForValue(average);

            ctx.save();
            ctx.beginPath();
            ctx.moveTo(left, yPos);
            ctx.lineTo(right, yPos);
            ctx.lineWidth = 2;
            ctx.strokeStyle = dataset.borderColor; // Use the same color as the dataset
            ctx.stroke();
            ctx.restore();

            // Draw the text label
            ctx.save();
            ctx.fillStyle = dataset.borderColor;
            ctx.font = '12px Arial';
            ctx.fillText(`Avg: ${average.toFixed(2)}`, right - 80, yPos - 10 - (index * 15)); // Adjust position to avoid overlap
            ctx.restore();
        });
    }
};

// Register the plugin
Chart.register(averageLinePlugin);

function Charts(ajaxId, records, userTotals) {
    let menuName = $('.db-selected').attr('value');
    let firstLetter = menuName.charAt(0).toLowerCase();
    let canvasId = '#' + firstLetter + ajaxId;

    switch (ajaxId) {
        case 'u02':
            initializeAgencyOverviewChartForIndividuals(canvasId, records, userTotals, ajaxId);
            break;
        case 'u01': // agency overview
            initializePrintAgencyOverviewChart(canvasId, records, ajaxId);
            break;
        case 'q01': // quote metrics
            initializeQuoteMetricsChart(canvasId, records, ajaxId);
            break;
        case 'jcm01': // job completion metrics
            initializeJobCompletionMetricsChart(canvasId, records, ajaxId);
            break;
        case 'cto01': // cost to organization
            initializeCostToOrganizationChart(canvasId, records, ajaxId);
            break;
        case 'cjs01':
            initializeCompletedJobsSummaryChart(canvasId, records, ajaxId);
            break;
        case 'tc01':
            // Handle tc01 case if needed
            initializeTopClientsChart(canvasId, records, ajaxId);
            break;
        case 'm01':
            initializeMarginChart(canvasId, records, ajaxId);
            break;
        case 'rsc01':
            break;
        default:
            console.error('Invalid ajaxId:', ajaxId);
            break;
    }
}

function initializeMarginChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }

    const ctx = canvas.get(0).getContext('2d');
    const organizedData = organizeMarginData(records);

    const chartConfig = createMarginDatasets(organizedData);

    if (window.marginChart) {
        window.marginChart.destroy();
    }

    window.marginChart = new Chart(ctx, chartConfig);
};

function organizeMarginData(records) {

    let organizedData = {
        records: []
    };

    records.forEach(record => {
        const date = record.Date.split('T')[0];
        const mgin = record.Aggregates.Margin;
        organizedData.records.push({
            date,
            mgin
        });
    });
    return organizedData;
};

function createMarginDatasets(records) {
    
    const labels = records.records.map(item => item.date);
    const dataValues = records.records.map(item => item.mgin);

    let minValue = Math.min(...dataValues);
    let maxValue = Math.max(...dataValues);
    let minOffset = minValue * .05;
    let maxOffset = maxValue * .05;

    minValue = minValue - minOffset;
    maxValue = maxValue + maxOffset;

    const chartConfig = {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Margin',
                data: dataValues,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: false,
                    min: minValue,
                    max: maxValue
                }
            }
        }
    };

    return chartConfig;
};

function initializeTopClientsChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }

    const ctx = canvas.get(0).getContext('2d');
    const organizedData = organizeTopClientData(records);

    const chartData = createTopClientDatasets(organizedData.records);

    if (window.topClientsChart) {
        window.topClientsChart.destroy();
    }

    window.topClientsChart = new Chart(ctx, chartData);

    initializeTopClientsTable();
};

function organizeTopClientData(records) {
};

function createTopClientDatasets(records) {
};

function initializePrintAgencyOverviewChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }
    const ctx = canvas.get(0).getContext('2d');

    const organizedData = organizePrintAgencyOverviewData(records);

    const chartData = createPrintAgencyOverviewChartDatasets(organizedData.records);

    if (window.agencyOverviewChart) {
        window.agencyOverviewChart.destroy();
    }

    window.agencyOverviewChart = new Chart(ctx, chartData);

    initializeUtilizationTable();
};

function organizePrintAgencyOverviewData(records) {
    //each record in records has an Aggregates object that contains the totals for that date
    //i need a collection of dates with their AvgUtilization from each Aggregates object; do not worry about users
    let organizedData = {
        records: []
    };

    records.forEach(record => {
        const date = record.Date.split('T')[0];
        const utilization = record.Aggregates.AvgUtilization;
        organizedData.records.push({
            x: date,
            y: utilization
        });
    });

    return organizedData;
};

function createPrintAgencyOverviewChartDatasets(records) {
    const labels = records.map(item => item.x);
    const dataValues = records.map(item => (item.y * 100.00));

    const chartConfig = {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Utilization',
                data: dataValues,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: true,
                    min: 0,
                    max: 120
                }
            }
        }
    };
    return chartConfig;
};

function createIndividualAgencyOverviewChartDatasets(users) {
    return Object.keys(users).map(userName => {
        return {
            label: userName,
            data: users[userName],
            fill: false,
            borderColor: getRandomColor(),
            tension: 0.1
        };
    });
}

function initializeAgencyOverviewChartForIndividuals(canvasId, records, userTotals, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }
    const ctx = canvas.get(0).getContext('2d');

    const organizedData = organizeIndividualAgencyOverviewData(records);

    const chartData = {
        labels: organizedData.dates,
        datasets: createIndividualAgencyOverviewChartDatasets(organizedData.users)
    };

    if (window.agencyOverviewChart) {
        window.agencyOverviewChart.destroy();
    }

    window.agencyOverviewChart = new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: true,
                    min: 0,
                    max: 120
                }
            }
        }
    });

    $('.individual-metric-wrapper .utilization .card-data-wrapper table tbody').empty();
    for (let i = 0; i < userTotals.length; i++) {
        $('.individual-metric-wrapper .utilization .card-data-wrapper table tbody').append(
            `<tr>
                <td data-emp-name="${userTotals[i][0].UserName}"><input type="checkbox" class="g-display-cb" checked /></td>
                <td>${userTotals[i][0].UserName}</td>
                <td>${userTotals[i][0].TotalEarlyClockOuts}</td>
                <td>${userTotals[i][0].TotalLateClockIns}</td>
                <td>${userTotals[i][0].TotalWorkedHours}</td>
                <td>${userTotals[i][0].TotalJobTime}</td>
                <td>${(userTotals[i][0].AvgUtilization * 100)}</td>
            </tr>`
        );
    }

    initializeIndividalAgencyOverviewDatatable();
}

function initializeIndividalAgencyOverviewDatatable() {
    if (iAgencyOverviewTable) {
        iAgencyOverviewTable.destroy();
    }

    iAgencyOverviewTable = $('#i_overview_table').DataTable();
};

function intializeCompletedJobsSummaryChart(canvasId, records, ajaxId) {
    initializeCompletedJobSummaryTable();
};

function initializeCompletedJobSummaryTable() {
    if (aCompletedJobSummaryTable) {
        aCompletedJobSummaryTable.destroy();
    }

    aCompletedJobSummaryTable = $('#completed_job_summary_table').DataTable();
};

function initializeTopClientsTable() {
    if (aTopClientsTable) {
        aTopClientsTable.destroy();
    }

    aTopClientsTable = $('#top_clients_table').DataTable();
};

function initializeUtilizationTable() {
    if (aUtilizationTable) {
        aUtilizationTable.destroy();
    }

    aUtilizationTable = $('#utilization_table').DataTable();
};

function initializeQuoteMetricsChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }
    const ctx = canvas.get(0).getContext('2d');

    const quoteConversionValues = records.map(item => {
        const formattedDate = item.Date.split('T')[0];
        return { x: formattedDate, y: item.Data.PercentConverted };
    });

    let minValue = Math.min(...quoteConversionValues.map(item => item.y));
    let maxValue = Math.max(...quoteConversionValues.map(item => item.y));
    let minOffset = minValue * .05;
    let maxOffset = maxValue * .05;
    minValue = minValue - minOffset;
    maxValue = maxValue + maxOffset;

    if (window.quoteMetricsChart) {
        window.quoteMetricsChart.destroy();
    }

    window.quoteMetricsChart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [
                {
                    label: 'Conversion Rate',
                    data: quoteConversionValues,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: true,
                    min: minValue,
                    max: maxValue
                }
            }
        }
    });
}

function initializeJobCompletionMetricsChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }
    const ctx = canvas.get(0).getContext('2d');

    const jobCompletionMetricsValues = records.map(item => {
        const formattedDate = item.Date.split('T')[0];
        return {
            Date: formattedDate,
            Data: {
                NotStartedJobs: item.Data.NotStartedJobs,
                OnTimeJobs: item.Data.OnTimeJobs,
                PastDueJobs: item.Data.PastDueJobs
            }
        };
    });

    const NotStarted = jobCompletionMetricsValues.map(item => ({ x: item.Date, y: item.Data.NotStartedJobs }));
    const PastDue = jobCompletionMetricsValues.map(item => ({ x: item.Date, y: item.Data.PastDueJobs }));
    const OnTime = jobCompletionMetricsValues.map(item => ({ x: item.Date, y: item.Data.OnTimeJobs }));

    if (window.jobCompletionMetricsChart) {
        window.jobCompletionMetricsChart.destroy();
    }

    window.jobCompletionMetricsChart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [
                {
                    label: 'On Time Jobs',
                    data: OnTime,
                    borderColor: 'rgba(46, 186, 15,1)',
                    backgroundColor: 'rgba(46, 186, 15, 0.2)',
                    borderWidth: 2
                },
                {
                    label: 'Past Due Jobs',
                    data: PastDue,
                    borderColor: 'rgba(186, 15, 61, 1)',
                    backgroundColor: 'rgba(186, 15, 61, 0.2)',
                    borderWidth: 2
                },
                {
                    label: 'Not Started Jobs',
                    data: NotStarted,
                    borderColor: 'rgba(68, 154, 206, 1)',
                    backgroundColor: 'rgba(68, 154, 206, 0.2)',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: true,
                    min: 0,
                    max: 10
                }
            }
        }
    });
}

function initializeCostToOrganizationChart(canvasId, records, ajaxId) {
    const canvas = $(canvasId);
    if (!canvas.length) {
        console.error('Canvas element not found:', canvasId);
        return;
    }
    const ctx = canvas.get(0).getContext('2d');

    const costToOrgValues = records.map(item => {
        const formattedDate = item.Date.split('T')[0];
        return {
            Date: formattedDate,
            Data: { JobCost: item.Data.TotalJobCost, MaterialCost: item.Data.TotalMaterialCost }
        };
    });

    const jobCostValues = costToOrgValues.map(item => ({ x: item.Date, y: Number(item.Data.JobCost).toFixed(2) }));
    const materialCostValues = costToOrgValues.map(item => ({ x: item.Date, y: Number(item.Data.MaterialCost).toFixed(2) }));

    let minValue = Math.min(...jobCostValues.map(item => item.y));
    let maxValue = Math.max(...jobCostValues.map(item => item.y));

    let minOffset = minValue * .05;
    let maxOffset = maxValue * .05;

    minValue = minValue - minOffset;
    maxValue = maxValue + maxOffset;

    if (window.orgCostChart) {
        window.orgCostChart.destroy();
    }

    window.orgCostChart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [
                {
                    label: 'Job Cost',
                    data: jobCostValues,
                    borderColor: 'rgba(46, 186, 15,1)',
                    backgroundColor: 'rgba(46, 186, 15, 0.2)',
                    borderWidth: 2
                },
                {
                    label: 'Material Cost',
                    data: materialCostValues,
                    borderColor: 'rgba(186, 15, 61, 1)',
                    backgroundColor: 'rgba(186, 15, 61, 0.2)',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: true,
                    min: minValue,
                    max: maxValue
                }
            }
        }
    });
}

function organizeIndividualAgencyOverviewData(records) {
    const organizedData = {
        users: {},
        dates: []
    };

    records.forEach(record => {
        const date = record.Date.split('T')[0];
        organizedData.dates.push(date);

        record.Data.forEach(user => {
            if (!organizedData.users[user.UserName]) {
                organizedData.users[user.UserName] = [];
            }
            console.log(user.AvgUtilization);
            organizedData.users[user.UserName].push({
                x: date,
                y: user.AvgUtilization * 100.00
            });
        });
    });

    return organizedData;
}

function ToggleUserDisplay() {
    let $cb = $(this);
    let empName = $cb.parent().attr('data-emp-name');
    let datasets = window.agencyOverviewChart.data.datasets;
    let dataset = datasets.find(ds => ds.label === empName);

    if (dataset) {
        if ($cb.is(':checked')) {
            dataset.hidden = false;
        } else {
            dataset.hidden = true;
        }

        window.agencyOverviewChart.update();
    }
};

// Function to create a chart (currently not used; intended to be a generic implementation)
const createChart = (chartData, canvasId) => {

    const ctx = document.getElementById(canvasId).getContext('2d');

    // Calculate min and max for y-axis
    const allDataPoints = chartData.datasets.flatMap(dataset => dataset.data);
    const minY = Math.min(...allDataPoints);
    const maxY = Math.max(...allDataPoints);

    // Chart configuration
    const config = {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: chartData.datasets,
        },
        options: {
            responsive: true,
            plugins: {
                averageLine: {}
            },
            scales: {
                y: {
                    beginAtZero: false,
                    min: minY,
                    max: maxY,
                }
            }
        }
    };

    // Create the chart
    new Chart(ctx, config);
};

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

$(function () { })
    .on('click', '.g-display-cb', ToggleUserDisplay);
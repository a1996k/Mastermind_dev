﻿function LoadJobMetrics(recordId) {
    $.ajax({
        type: 'GET',
        url: ProcessUrl('LoadJobMetrics') + '/' + recordId,
        success: function (data) {
            try {
                let res = JSON.parse(data);
                $('.job-stat-display').html(res.html);
            } catch (e) {

            }
        }
    });
};

$(function () {
    $('.billing-record-lookup').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: ProcessUrl("AutocompleteReadyToBillJobNumber"),
                type: 'GET',
                data: {
                    'q': request.term
                },
                success: function (data) {
                    let d = JSON.parse(data);

                    response($.map(d, function (item) {
                        return { label: item.JobNumber, value: item.JobNumber, recordId: item.Id }
                    }));
                }
            });
        },
        select: function (event, ui) {
            let recordId = ui.item.recordId;
            LoadJobMetrics(recordId);
        }
    });
})